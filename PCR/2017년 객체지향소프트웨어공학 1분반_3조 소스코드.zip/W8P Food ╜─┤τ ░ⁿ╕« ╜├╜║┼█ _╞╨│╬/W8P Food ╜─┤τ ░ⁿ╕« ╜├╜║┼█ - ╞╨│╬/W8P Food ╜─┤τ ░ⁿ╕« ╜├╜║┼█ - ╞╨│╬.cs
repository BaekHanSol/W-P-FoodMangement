﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace W8P_Food_식당_관리_시스템___패널
{
    public partial class W8P_Food_Management_System_Panel : Form
    {
        public static int MAX_BUTTON = 20;  //만들수 있는 버튼의 최대 갯수
        public int count = 0;               //만들어진 버튼의 수
        public Button[] newBtn = new Button[MAX_BUTTON];
        MdiClient mdi = null;

        // 주문 정보 관리
        public DUI2001 dui2001 = null; // 패널 식단 조회
        public DUI2002 dui2002 = null; // 주문 등록
        public DUI2003 dui2003 = null; // 주문 조회
        public DUI2004 dui2004 = null; // 주문 수정

        public W8P_Food_Management_System_Panel()
        {
            InitializeComponent();

            foreach (Control ctl in this.Controls)  //MdiContainer의 색상을 변경
            {
                try
                {
                    mdi = (MdiClient)ctl;
                    mdi.BackColor = this.BackColor;
                }
                catch (InvalidCastException e)
                {
                }
            }
        }

        private void treeView1_AfterSelect(object sender, TreeViewEventArgs e)
        {
            Form form = null;
            panel1.Controls.Clear();

            if (treeView1.SelectedNode.Level == 2 && count >= MAX_BUTTON)            
                MessageBox.Show("열린 창이 너무 많습니다.");

            else if (treeView1.SelectedNode.Name == "uc2001") // 패널 식단 조회
            {
                if (dui2001 == null)
                {
                    dui2001 = new DUI2001(this);
                    dui2001.TopLevel = false;
                    dui2001.Dock = System.Windows.Forms.DockStyle.Fill;
                }

                form = dui2001;
                form.FormBorderStyle = FormBorderStyle.None;
                panel1.Controls.Add(form);
                form.Show();
            }

            else if (treeView1.SelectedNode.Name == "uc2002") // 주문 조회
            {
                if (dui2003 == null)
                {
                    dui2003 = new DUI2003(this);
                    dui2003.TopLevel = false;
                    dui2003.Dock = System.Windows.Forms.DockStyle.Fill;
                }

                form = dui2003;
                form.FormBorderStyle = FormBorderStyle.None;
                panel1.Controls.Add(form);
                form.Show();
            }
        }
    }
}
