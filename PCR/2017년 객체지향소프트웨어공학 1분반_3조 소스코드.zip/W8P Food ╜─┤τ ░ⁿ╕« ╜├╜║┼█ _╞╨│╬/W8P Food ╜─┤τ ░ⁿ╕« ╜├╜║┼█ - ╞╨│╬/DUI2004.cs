﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace W8P_Food_식당_관리_시스템___패널
{
    public partial class DUI2004 : Form
    {
        private MySqlConnection connection;

        public DUI2004()
        {
            InitializeComponent();
        }

        private void DUI2004_Load(object sender, EventArgs e)
        {
            string strConn = "Server=218.233.209.73;Port=10040;Database=w8p_foodmanagement_system;Uid=root;Pwd=scotish1;pooling = false; convert zero datetime=True";
            connection = new MySqlConnection(strConn);

            if (this.OpenConnection() == true)
            {
                string querry = "SELECT * FROM orderinfo";
                MySqlCommand cmd = new MySqlCommand(querry, connection);
                cmd.ExecuteNonQuery();

                MySqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    string orderId = reader["id"].ToString();
                    string menuId = reader["menuId"].ToString();
                    string menuName = getMenuName(menuId);
                    string quantity = reader["quantity"].ToString();
                    string tableNum = reader["tableNum"].ToString();

                    dataGridView1.Rows.Add(orderId, menuName, quantity, tableNum);
                }
            }
        }

        private bool OpenConnection()
        {
            try
            {
                connection.Open();
                return true;
            }
            catch (MySqlException ex)
            {
                switch (ex.Number)
                {
                    case 0:
                        MessageBox.Show("Cannot connect to server. Contact administrator");
                        break;
                    case 1045:
                        MessageBox.Show("Invalid username/password, please try again");
                        break;
                    default:
                        MessageBox.Show(ex.Message);
                        break;
                }

                return false;
            }
        }

        private bool CloseConnection()
        {
            try
            {
                connection.Close();
                return true;
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message);
                return false;
            }
        }

        private string getMenuName(string menuId)
        {
            string strConn = "Server=218.233.209.73;Port=10040;Database=w8p_foodmanagement_system;Uid=root;Pwd=scotish1;pooling = false; convert zero datetime=True";
            MySqlConnection conn = new MySqlConnection(strConn);
            conn.Open();

            string querry = "SELECT name FROM menu WHERE id=\'" + menuId + "\'";
            MySqlCommand cmd = new MySqlCommand(querry, conn);
            cmd.ExecuteNonQuery();

            MySqlDataReader rdr = cmd.ExecuteReader();
            rdr.Read();
            string menuName = rdr["name"].ToString();
            conn.Close();

            return menuName;
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            string strConn = "Server=218.233.209.73;Port=10040;Database=w8p_foodmanagement_system;Uid=root;Pwd=scotish1;pooling = false; convert zero datetime=True";
            MySqlConnection conn = new MySqlConnection(strConn);
            conn.Open();

            string orderId = this.dataGridView1.Rows[this.dataGridView1.CurrentCellAddress.Y].Cells[0].Value.ToString();
            string querry = "UPDATE orderInfo SET menuId=@menuId, quantity=@quantity WHERE id=@id";
            MySqlCommand cmd = new MySqlCommand(querry, conn);

            string menuId = getMenuId(txtMenu.Text);
            cmd.Parameters.AddWithValue("@id", orderId);
            cmd.Parameters.AddWithValue("@menuId", menuId);
            cmd.Parameters.AddWithValue("@quantity", txtQuantity.Text);
            cmd.ExecuteNonQuery();
            conn.Close();

            MessageBox.Show("주문 수정이 완료되었습니다.");
        }

        private string getMenuId(string menuName)
        {
            string strConn = "Server=218.233.209.73;Port=10040;Database=w8p_foodmanagement_system;Uid=root;Pwd=scotish1;pooling = false; convert zero datetime=True";
            MySqlConnection conn = new MySqlConnection(strConn);
            conn.Open();

            string querry = "SELECT id FROM menu WHERE name=\'" + menuName + "\'";
            MySqlCommand cmd = new MySqlCommand(querry, conn);
            cmd.ExecuteNonQuery();

            MySqlDataReader rdr = cmd.ExecuteReader();
            rdr.Read();
            string menuId = rdr["id"].ToString();
            conn.Close();

            return menuId;
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }

        private void txtMenu_TextChanged(object sender, EventArgs e)
        {
            if(txtMenu.TextLength <= 0 || txtMenu.TextLength > 10)
                MessageBox.Show("[오류] 입력정보가 잘못되었습니다.");
        }

        private void txtQuantity_TextChanged(object sender, EventArgs e)
        {
            if (Convert.ToInt64(txtQuantity.Text) < 0)
                MessageBox.Show("[오류] 수량이 잘못되었습니다.");

            decimal num = 0;
            bool isFormatOk = decimal.TryParse(txtQuantity.Text, out num);

            if (isFormatOk == false)
                MessageBox.Show("[오류] 숫자를 입력해주세요.");
        }
    }
}