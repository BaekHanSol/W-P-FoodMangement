﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace W8P_Food_식당_관리_시스템___패널
{
    public partial class DUI2002 : Form
    {
        private MySqlConnection connection;
        private int orderId = 1;
        
        public DUI2002(string m_menuName)
        {
            InitializeComponent();
            menuName.Text = m_menuName;
        }

        private void DUI2002_Load(object sender, EventArgs e)
        {
            string strConn = "Server=218.233.209.73;Port=10040;Database=w8p_foodmanagement_system;Uid=root;Pwd=scotish1;pooling = false; convert zero datetime=True";
            connection = new MySqlConnection(strConn);
        }

        private void btnRegister_Click(object sender, EventArgs e)
        {
            if (this.OpenConnection() == true)
            {
                string getIdQuerry = "select id from menu WHERE name=\'" + menuName.Text + "\'";
                MySqlCommand cmd = new MySqlCommand(getIdQuerry, connection);
                cmd.ExecuteNonQuery();

                MySqlDataReader rdr = cmd.ExecuteReader();
                rdr.Read();
                string menuId = rdr["id"].ToString();
                rdr.Close();
                
                Random r = new Random();
                int tableNum = r.Next(1, 24);

                string query = "INSERT INTO orderinfo(menuId, quantity, tableNum)" + "VALUES(@menuId, @quantity, @tableNum)";
                cmd = new MySqlCommand(query, connection);
                cmd.Parameters.AddWithValue("@menuId", Convert.ToInt32(menuId));

                if(essentialCheck() == true && formatCheck() == true)
                {
                    int quantity = Convert.ToInt32(txtAmount.Text);
                    cmd.Parameters.AddWithValue("@quantity", quantity);
                    cmd.Parameters.AddWithValue("@tableNum", tableNum);
                    cmd.ExecuteNonQuery();
                    orderId++;

                    MessageBox.Show("주문 접수가 완료되었습니다!");
                    this.Dispose();
                }

                this.CloseConnection();
            }
        }

        private bool OpenConnection()
        {
            try
            {
                connection.Open();
                return true;
            }
            catch (MySqlException ex)
            {
                switch (ex.Number)
                {
                    case 0:
                        MessageBox.Show("Cannot connect to server. Contact administrator");
                        break;
                    case 1045:
                        MessageBox.Show("Invalid username/password, please try again");
                        break;
                    default:
                        MessageBox.Show(ex.Message);
                        break;
                }

                return false;
            }
        }

        private bool CloseConnection()
        {
            try
            {
                connection.Close();
                return true;
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message);
                return false;
            }
        }

        private bool essentialCheck()
        {
            if (txtAmount.Text == "")
            {
                MessageBox.Show("[오류] 필수 정보가 입력되지 않았습니다.");
                return false;
            }

            return true;
        }

        private bool formatCheck()
        {
            if (Convert.ToInt64(txtAmount.Text) < 0)
            {
                MessageBox.Show("[오류] 수량이 잘못되었습니다.");
                return false;
            }

            if (txtAmount.TextLength > 10)
            {
                MessageBox.Show("[오류] 입력정보가 잘못되었습니다.");
                return false;
            }

            return true;
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }

        private void txtAmount_TextChanged(object sender, EventArgs e)
        {
            decimal num = 0;
            bool isFormatOk = decimal.TryParse(txtAmount.Text, out num);

            if (isFormatOk == false)
                MessageBox.Show("[오류] 숫자를 입력해주세요.");
        }
    }
}
