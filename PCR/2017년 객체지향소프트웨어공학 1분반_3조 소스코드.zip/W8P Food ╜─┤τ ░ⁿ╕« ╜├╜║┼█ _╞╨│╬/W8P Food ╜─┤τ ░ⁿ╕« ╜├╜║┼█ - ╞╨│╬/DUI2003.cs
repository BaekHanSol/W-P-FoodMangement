﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace W8P_Food_식당_관리_시스템___패널
{
    public partial class DUI2003 : Form
    {
        private MySqlConnection connection;
        W8P_Food_Management_System_Panel mainform;
        public DUI2004 dui2004;

        public DUI2003(W8P_Food_Management_System_Panel f)
        {
            mainform = f;
            InitializeComponent();
        }

        private void DUI2003_Load(object sender, EventArgs e)
        {
            string strConn = "Server=218.233.209.73;Port=10040;Database=w8p_foodmanagement_system;Uid=root;Pwd=scotish1;pooling = false; convert zero datetime=True";
            connection = new MySqlConnection(strConn);

            if (this.OpenConnection() == true)
            {
                string querry = "SELECT * FROM orderinfo";
                MySqlCommand cmd = new MySqlCommand(querry, connection);
                cmd.ExecuteNonQuery();

                MySqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    string orderId = reader["id"].ToString();
                    string menuId = reader["menuId"].ToString();
                    string menuName = getMenuName(menuId);
                    string quantity = reader["quantity"].ToString();
                    string tableNum = reader["tableNum"].ToString();

                    dataGridView1.Rows.Add(orderId, menuName, quantity, tableNum);
                }
            }

            this.CloseConnection();
        }

        private bool OpenConnection()
        {
            try
            {
                connection.Open();
                return true;
            }
            catch (MySqlException ex)
            {
                switch (ex.Number)
                {
                    case 0:
                        MessageBox.Show("Cannot connect to server. Contact administrator");
                        break;
                    case 1045:
                        MessageBox.Show("Invalid username/password, please try again");
                        break;
                    default:
                        MessageBox.Show(ex.Message);
                        break;
                }

                return false;
            }
        }

        private string getMenuName(string menuId)
        {
            string strConn = "Server=218.233.209.73;Port=10040;Database=w8p_foodmanagement_system;Uid=root;Pwd=scotish1;pooling = false; convert zero datetime=True";
            MySqlConnection conn = new MySqlConnection(strConn);
            conn.Open();

            string querry = "SELECT name FROM menu WHERE id=\'" + menuId + "\'";
            MySqlCommand cmd = new MySqlCommand(querry, conn);
            cmd.ExecuteNonQuery();

            MySqlDataReader rdr = cmd.ExecuteReader();
            rdr.Read();
            string menuName = rdr["name"].ToString();
            conn.Close();

            return menuName;
        }

        private bool CloseConnection()
        {
            try
            {
                connection.Close();
                return true;
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message);
                return false;
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            string orderId = this.dataGridView1.Rows[this.dataGridView1.CurrentCellAddress.Y].Cells[0].Value.ToString();

            string strConn = "Server=218.233.209.73;Port=10040;Database=w8p_foodmanagement_system;Uid=root;Pwd=scotish1;pooling = false; convert zero datetime=True";
            connection = new MySqlConnection(strConn);

            if (this.OpenConnection() == true)
            {
                string query = "DELETE from orderinfo WHERE id=@id";
                MySqlCommand cmd = new MySqlCommand(query, connection);

                cmd.Parameters.AddWithValue("@id", orderId);
                cmd.ExecuteNonQuery();
                this.CloseConnection();
                MessageBox.Show("주문 삭제가 완료되었습니다.");
            }

            resetDataSheet();
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            if (dui2004 == null)
                dui2004 = new DUI2004();

            dui2004.ShowDialog();
            resetDataSheet();
        }

        private void resetDataSheet()
        {
            this.dataGridView1.Rows.Clear();
            string strConn = "Server=218.233.209.73;Port=10040;Database=w8p_foodmanagement_system;Uid=root;Pwd=scotish1;pooling = false; convert zero datetime=True";
            connection = new MySqlConnection(strConn);

            if (this.OpenConnection() == true)
            {
                string querry = "SELECT * FROM orderinfo";
                MySqlCommand cmd = new MySqlCommand(querry, connection);
                cmd.ExecuteNonQuery();

                MySqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    string orderId = reader["id"].ToString();
                    string menuId = reader["menuId"].ToString();
                    string menuName = getMenuName(menuId);
                    string quantity = reader["quantity"].ToString();
                    string tableNum = reader["tableNum"].ToString();

                    dataGridView1.Rows.Add(orderId, menuName, quantity, tableNum);
                }
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            mainform.dui2003 = null;
            this.Dispose();
        }
    }
}
