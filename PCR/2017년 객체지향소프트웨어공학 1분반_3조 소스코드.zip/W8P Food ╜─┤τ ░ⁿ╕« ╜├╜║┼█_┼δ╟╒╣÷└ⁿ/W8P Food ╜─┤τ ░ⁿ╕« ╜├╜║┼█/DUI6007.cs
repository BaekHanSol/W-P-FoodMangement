﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using MySql.Data.Common;


namespace W8P_Food_식당_관리_시스템
{
    public partial class DUI6007 : Form
    {
        private MySqlConnection connection;
        W8P_Food_Management_System mainform;

        public DUI6007(W8P_Food_Management_System f)
        {
            mainform = f;
            InitializeComponent();
        }

        private bool OpenConnection()
        {
            try
            {
                connection.Open();
                return true;
            }
            catch (MySqlException ex)
            {
                switch (ex.Number)
                {
                    case 0:
                        MessageBox.Show("Cannot connect to server. Contact administrator");
                        break;
                    case 1045:
                        MessageBox.Show("Invalid username/password, please try again");
                        break;
                    default:
                        MessageBox.Show(ex.Message);
                        break;
                }
                return false;
            }
        }

        private bool CloseConnection()
        {
            try
            {
                connection.Close();
                return true;
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message);
                return false;
            }
        }

        

        // 등록
        private void button1_Click(object sender, EventArgs e)
        {
            if (txtName.Text == null || txtPhone.Text == null || txtAddress.Text == "" || txtSerial.Text == ""
                || txtCharger.Text == "" || txtPhone.Text == "")
            {
                MessageBox.Show("데이터를 모두 입력하세요.");
                return;
            }

            string strConn = "Server=218.233.209.73;Port=10040;Database=w8p_foodmanagement_system;Uid=root;Pwd=scotish1;pooling = false; convert zero datetime=True";
            connection = new MySqlConnection(strConn);

            // 발주처 등록
            if (this.OpenConnection() == true)
            {
                ProviderInfo pi = new ProviderInfo();

                pi.name = txtName.Text;
                pi.phone = txtNum.Text;
                pi.address = txtAddress.Text;
                pi.registrationNum= txtSerial.Text;
                pi.chargerName = txtCharger.Text;
                pi.chargerNum = txtPhone.Text;
                pi.constractDate = dateTimePicker1.Value;
                pi.expirationDate = dateTimePicker2.Value;

                // 중복 검사
                string query = "SELECT name from provider where name=@name";
                MySqlCommand cmd = new MySqlCommand(query, connection);

                cmd.Parameters.AddWithValue("@name", pi.name);
                MySqlDataReader sr = cmd.ExecuteReader();

                if (sr.HasRows)
                {
                    // 중복데이터가 있는 경우
                    MessageBox.Show("회사명이 중복 됩니다.");
                    return;
                }
                cmd.Dispose();

                query = "INSERT INTO provider(name, phone, address, registrationNum, chargerName, chargerNum, constractDate, expirationDate)" + "VALUES(@name, @phone, @address, @registrationNum, @chargerName, @chargerNum, @constractDate, @expirationDate)";
                cmd = new MySqlCommand(query, connection);

                cmd.Parameters.AddWithValue("@name", pi.name);
                cmd.Parameters.AddWithValue("@phone", pi.phone);
                cmd.Parameters.AddWithValue("@address", pi.address);
                cmd.Parameters.AddWithValue("@registrationNum", pi.registrationNum);
                cmd.Parameters.AddWithValue("@chargerName", pi.chargerName);
                cmd.Parameters.AddWithValue("@chargerNum", pi.chargerNum);
                cmd.Parameters.AddWithValue("@constractDate", pi.constractDate);
                cmd.Parameters.AddWithValue("@expirationDate", pi.expirationDate);

                cmd.ExecuteNonQuery();
                this.CloseConnection();
            }

            mainform.dui6008 = null;

            txtAddress.Text = "";
            txtCharger.Text = "";
            txtName.Text = "";
            txtNum.Text = "";
            txtPhone.Text = "";
            txtSerial.Text = "";
        }

        // 취소
        private void button2_Click(object sender, EventArgs e)
        {
            mainform.dui6007 = null;
            this.Dispose();
        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void textBox7_TextChanged(object sender, EventArgs e)
        {

        }

        private void DUI6007_Load(object sender, EventArgs e)
        {

        }
    }
}
