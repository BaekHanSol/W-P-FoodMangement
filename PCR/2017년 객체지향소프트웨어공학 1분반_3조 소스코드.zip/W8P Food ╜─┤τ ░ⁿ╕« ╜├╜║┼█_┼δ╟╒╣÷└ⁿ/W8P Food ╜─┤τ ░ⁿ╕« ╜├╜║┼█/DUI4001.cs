﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using MySql.Data.Common;
namespace W8P_Food_식당_관리_시스템
{
    public partial class DUI4001 : Form
    {
        private MySqlConnection connection;
        private MySqlDataAdapter mySqlDataAdapter;
        W8P_Food_Management_System mainform;

        public DUI4001(W8P_Food_Management_System f)
        {
            InitializeComponent();
            mainform = f;
        }
        private bool OpenConnection()
        {
            try
            {
                connection.Open();
                return true;
            }
            catch (MySqlException ex)
            {
                switch (ex.Number)
                {
                    case 0:
                        MessageBox.Show("Cannot connect to server. Contact administrator");
                        break;
                    case 1045:
                        MessageBox.Show("Invalid username/password, please try again");
                        break;
                    default:
                        MessageBox.Show(ex.Message);
                        break;
                }
                return false;
            }
        }

        private bool CloseConnection()
        {
            try
            {
                connection.Close();
                return true;
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message);
                return false;
            }
        }
        private void DUI4001_Load(object sender, EventArgs e)
        {
            string strConn = "Server=218.233.209.73;Port=10040;Database=w8p_foodmanagement_system;Uid=root;Pwd=scotish1;pooling = false; convert zero datetime=True";
            connection = new MySqlConnection(strConn);
        }
        private bool formatCheck()
        {
            decimal num = 0;
            string amount = amountTxt.Text;

            bool isFormatOk1 = decimal.TryParse(amount, out num);


            if (isFormatOk1 == false)
            {
                MessageBox.Show("[오류] 형식이 일치하지 않습니다.");
                return false;
            }

            return true;
        }
        private void button1_Click(object sender, EventArgs e)
        {
            // 유효성
            if (!formatCheck())
                return;

            if (materialTxt.Text == "" || amountTxt.Text == "")
            {
                MessageBox.Show("데이터를 모두 입력하세요.");
                return;
            }

            if (materialTxt.TextLength > 11)
            {
                MessageBox.Show("식자재명의 길이는 10자리 이내로 입력해주세요.");
                return;
            }

            if (amountTxt.TextLength > 11)
            {
                MessageBox.Show("수량의 길이는 10자리 이내로 입력해주세요.");
                return;
            }


            string strConn = "Server=218.233.209.73;Port=10040;Database=w8p_foodmanagement_system;Uid=root;Pwd=scotish1;pooling = false; convert zero datetime=True";
            connection = new MySqlConnection(strConn);

            // 발주처 등록
            if (this.OpenConnection() == true)
            {
                MaterialInfo mi = new MaterialInfo();
                mi.materialName = materialTxt.Text.ToString();
                mi.amount = Convert.ToInt32(amountTxt.Text);


                ///////////////////////// 경고 : 테이블에 첫 튜플 존재 X시 오류남!!!(cause: id++이 없으므로)//////////////////////

                // 쿼리문 작성
                string query = "INSERT INTO material(name, amount)" + "VALUES(@name, @amount)";
                MySqlCommand cmd = new MySqlCommand(query, connection);

                cmd.Parameters.AddWithValue("@name", mi.materialName);
                cmd.Parameters.AddWithValue("@amount", mi.amount);

                cmd.ExecuteNonQuery();
                this.CloseConnection();

                amountTxt.Text = "";
                materialTxt.Text = "";
                mainform.dui4002 = null;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            mainform.dui4001 = null;
            this.Dispose();
        }
    }
}
