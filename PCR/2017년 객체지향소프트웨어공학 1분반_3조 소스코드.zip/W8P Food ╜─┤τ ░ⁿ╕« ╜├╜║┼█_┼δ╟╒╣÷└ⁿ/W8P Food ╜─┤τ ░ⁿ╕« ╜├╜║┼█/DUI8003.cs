﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using MySql.Data.Common;

namespace W8P_Food_식당_관리_시스템
{
    public partial class DUI8003 : Form
    {
        private MySqlConnection connection;
        private MySqlDataAdapter mySqlDataAdapter;
        DUI8002 dui8002;
        public DUI8003(DUI8002 f)
        {
            dui8002 = f;
            InitializeComponent();
        }
        private bool OpenConnection()
        {
            try
            {
                connection.Open();
                return true;
            }
            catch (MySqlException ex)
            {
                switch (ex.Number)
                {
                    case 0:
                        MessageBox.Show("Cannot connect to server. Contact administrator");
                        break;
                    case 1045:
                        MessageBox.Show("Invalid username/password, please try again");
                        break;
                    default:
                        MessageBox.Show(ex.Message);
                        break;
                }
                return false;
            }
        }

        private bool CloseConnection()
        {
            try
            {
                connection.Close();
                return true;
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message);
                return false;
            }
        }
        private void button2_Click(object sender, EventArgs e)
        {
            dui8002.dui8003 = null;
            this.Visible = false;
        }

        private void DUI8003_Load(object sender, EventArgs e)
        {
            this.Visible = true;
            MemberInfo mi = new MemberInfo();
            mi = dui8002.getInfo();
            MemberID.Text = Convert.ToString(mi.MemberId);
            MemberName.Text = mi.MemberName;
            PhoneNum.Text = mi.PhoneNum;
            dateTimePicker1.Value = mi.Birthdate;
            address.Text = mi.address;
            
            Point.Text = Convert.ToString(mi.Point);
            //Grade.Text = Convert.ToString(mi.Grade);
            gradecheck(mi);
        }
        public void gradecheck(MemberInfo mi)
        {
            if (mi.Point > 5000)
            {
                Grade.Text = "실버"; mi.Grade = "실버";
            }
            else if(mi.Point >20000)
            {
                Grade.Text = "골드"; mi.Grade = "골드";
            }
            else if(mi.Point > 50000)
            {
                Grade.Text = "플래티넘"; mi.Grade = "플래티넘";
            }
            else
            {
                Grade.Text = "브론즈"; mi.Grade = "브론즈";

            }
        }
        private void button1_Click(object sender, EventArgs e)
        {
            string phone = PhoneNum.Text;
            int numChk = 0; ;
            bool isnum = int.TryParse(phone.Substring(0, 2), out numChk);
            bool isnum2 = int.TryParse(phone.Substring(4, 7), out numChk);
            bool isnum3 = int.TryParse(phone.Substring(9, 12), out numChk);
            if (MemberName.Text == "" || PhoneNum.Text == "" || address.Text == "")
            {
                MessageBox.Show("데이터를 모두 입력하세요.");
                return;
            }
            if (PhoneNum.TextLength != 13)
            {
                MessageBox.Show("핸드폰 번호의 길이 값은 13자리로 입력하세요.");
                return;
            }
            if (phone.Substring(3, 3) != "-" || phone.Substring(8, 8) != "-")
            {
                MessageBox.Show("전화번호 형식이 맞지 않습니다 4번째, 9 번짜리에는 - 가 들어가야 합니다.");
                return;
            }
            if (!isnum || !isnum2 || !isnum3)
            {
                MessageBox.Show("정확한 값을 입력하세요");
                return;
            }
            if (MemberName.TextLength > 10)
            {
                MessageBox.Show("이름은 10자 이내로 입력해주세요");
                return;
            }
            string strConn = "Server=218.233.209.73;Port=10040;Database=w8p_foodmanagement_system;Uid=root;Pwd=scotish1;pooling = false; convert zero datetime=True";
            connection = new MySqlConnection(strConn);

            if (this.OpenConnection() == true)
            {
                MemberInfo mi = new MemberInfo();
                mi = dui8002.getInfo();

                mi.MemberId = Convert.ToInt32(MemberID.Text);
                mi.MemberName = MemberName.Text;
                mi.PhoneNum = PhoneNum.Text;
                mi.Birthdate = dateTimePicker1.Value;
                mi.address = address.Text;
                mi.Point = Convert.ToInt32(Point.Text);
                gradecheck(mi);
                //mi.Grade = Grade.Text;

                // 쿼리문 작성
                string query = "UPDATE member SET MemberName=@MemberName, PhoneNum=@PhoneNum, Birthdate=@Birthdate, address=@address, Grade=@Grade WHERE id=@id";
                MySqlCommand cmd = new MySqlCommand(query, connection);
               
                cmd.Parameters.AddWithValue("@MemberName", mi.MemberName);
                cmd.Parameters.AddWithValue("@PhoneNum", mi.PhoneNum);
                cmd.Parameters.AddWithValue("@Birthdate", mi.Birthdate);
                cmd.Parameters.AddWithValue("@address",mi.address);
                cmd.Parameters.AddWithValue("@Grade", mi.Grade);
                cmd.Parameters.AddWithValue("@id", mi.MemberId);
                cmd.ExecuteNonQuery();
                this.CloseConnection();

                this.Visible = false;
            }
        }
    }
}
