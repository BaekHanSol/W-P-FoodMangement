using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using MySql.Data.Common;

namespace W8P_Food_�Ĵ�_����_�ý���
{
    public partial class DUI1006 : Form
    {
        
        private MySqlConnection connection;
        private MySqlDataAdapter mySqlDataAdapter;
        W8P_Food_Management_System mainform;
        public DUI1007 dui1007;

        public DUI1006(W8P_Food_Management_System f)
        {
            mainform = f;
            InitializeComponent();
        }

        private void dataGridView1_RowValidated(object sender, DataGridViewCellEventArgs e)
        {
            DataTable changes = ((DataTable)dataGridView1.DataSource).GetChanges();

            if (changes != null)
            {
                MySqlCommandBuilder mcb = new MySqlCommandBuilder(mySqlDataAdapter);
                mySqlDataAdapter.UpdateCommand = mcb.GetUpdateCommand();
                mySqlDataAdapter.Update(changes);
                ((DataTable)dataGridView1.DataSource).AcceptChanges();
            }
        }

        private bool OpenConnection()
        {
            try
            {
                connection.Open();
                return true;
            }
            catch (MySqlException ex)
            {
                switch (ex.Number)
                {
                    case 0:
                        MessageBox.Show("Cannot connect to server. Contact administrator");
                        break;
                    case 1045:
                        MessageBox.Show("Invalid username/password, please try again");
                        break;
                    default:
                        MessageBox.Show(ex.Message);
                        break;
                }
                return false;
            }
        }

        private bool CloseConnection()
        {
            try
            {
                connection.Close();
                return true;
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message);
                return false;
            }
        }

        private void resetDataSheet()
        {
            string strConn = "Server=218.233.209.73;Port=10040;Database=w8p_foodmanagement_system;Uid=root;Pwd=scotish1;pooling = false; convert zero datetime=True";
            connection = new MySqlConnection(strConn);

            if (this.OpenConnection() == true)
            {
                mySqlDataAdapter = new MySqlDataAdapter("select * from pointsavingratio", connection);
                DataSet DS = new DataSet();
                mySqlDataAdapter.Fill(DS);
                dataGridView1.DataSource = DS.Tables[0];
                this.CloseConnection();
            }
        }

        private void DUI1006_Load(object sender, EventArgs e)
        {
            resetDataSheet();
        }
       

    //����Ʈ ������ ���� -> form1007�� �̵�
    private void button1_Click(object sender, EventArgs e)
        {
            if (dui1007 == null)
            {
                dui1007 = new DUI1007(this);
            }

            dui1007.ShowDialog();
            resetDataSheet();

        }

        //����
        private void button2_Click(object sender, EventArgs e)
        {
            string strConn = "Server=218.233.209.73;Port=10040;Database=w8p_foodmanagement_system;Uid=root;Pwd=scotish1;pooling = false; convert zero datetime=True";
            connection = new MySqlConnection(strConn);

            if (this.OpenConnection() == true)
            {
                Pointsavingratio ps = new Pointsavingratio();
                ps = getPoinsavingratioInfo();

                // ������ �ۼ�
                string query = "DELETE from pointsavingratio WHERE id=@id";
                MySqlCommand cmd = new MySqlCommand(query, connection);

                cmd.Parameters.AddWithValue("@id", ps.id);
                cmd.ExecuteNonQuery();
                this.CloseConnection();

                resetDataSheet();
                MessageBox.Show("��� : " + ps.grade + "/ ������ : " + ps.savingRatio + "%" + "\n���� �Ϸ�");
                return;
            }
        }

        //�ݱ�
        private void button3_Click(object sender, EventArgs e)
        {
            mainform.dui1006 = null;
            this.Dispose();
        }

        public Pointsavingratio getPoinsavingratioInfo()
        {
            Pointsavingratio ps = new Pointsavingratio();

            ps.id = Convert.ToInt32(dataGridView1.Rows[dataGridView1.CurrentCellAddress.Y].Cells[0].Value);
            ps.grade = dataGridView1.Rows[dataGridView1.CurrentCellAddress.Y].Cells[1].Value.ToString();
            ps.savingRatio = (double)Convert.ToInt32(dataGridView1.Rows[dataGridView1.CurrentCellAddress.Y].Cells[2].Value);

            return ps;
        }
    }
}
