﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace W8P_Food_식당_관리_시스템
{
    public class ReservationInfo
    {
        public int ReserveId;
        public int MemberId;
        public int tableNum;
        public DateTime ReserveDate;
        public int PersonNum;
    }
}
