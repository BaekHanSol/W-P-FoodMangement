using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using MySql.Data.Common;

namespace W8P_Food_�Ĵ�_����_�ý���
{
    public partial class DUI1003 : Form
    {
        public DUI1002 dui1002;
        private MySqlConnection connection;

        public DUI1003(DUI1002 f)
        {
            dui1002 = f;
            InitializeComponent();
        }

        private void DUI1003_Load(object sender, EventArgs e)
        {
        }

        private bool OpenConnection()
        {
            try
            {
                connection.Open();
                return true;
            }
            catch (MySqlException ex)
            {
                switch (ex.Number)
                {
                    case 0:
                        MessageBox.Show("Cannot connect to server. Contact administrator");
                        break;
                    case 1045:
                        MessageBox.Show("Invalid username/password, please try again");
                        break;
                    default:
                        MessageBox.Show(ex.Message);
                        break;
                }
                return false;
            }
        }

        private bool CloseConnection()
        {
            try
            {
                connection.Close();
                return true;
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message);
                return false;
            }
        }

        //�����Ϸ�
        private void button1_Click(object sender, EventArgs e)
        {
            if (dateTimePicker1.Value == null)
            {
                MessageBox.Show("�����͸� ��� �Է��ϼ���.");
                return;
            }

            string strConn = "Server=218.233.209.73;Port=10040;Database=w8p_foodmanagement_system;Uid=root;Pwd=scotish1;pooling = false; convert zero datetime=True";
            connection = new MySqlConnection(strConn);

            if (this.OpenConnection() == true)
            {
                BusinessDayInfo bi = new BusinessDayInfo();

                bi = dui1002.getBusinessDayInfo();

                bi.nonBusinessDay = dateTimePicker1.Value;

                // ������ �ۼ�
                string query = "UPDATE businessday SET nonBusinessDay=@nonBusinessDay WHERE id=@id";
                MySqlCommand cmd = new MySqlCommand(query, connection);

                cmd.Parameters.AddWithValue("@id", bi.id);
                cmd.Parameters.AddWithValue("@nonBusinessDay", bi.nonBusinessDay);
                cmd.ExecuteNonQuery();
                this.CloseConnection();

                this.Dispose();
                MessageBox.Show("�񿵾��� : " + bi.nonBusinessDay + "\n���� �Ϸ�");
                return;
            }

            dui1002.dui1003 = null;

        }

        //���� â �ݱ�
        private void button2_Click(object sender, EventArgs e)
        {
            dui1002.dui1003 = null;
            this.Dispose();
        }

    }
}
