﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using MySql.Data.Common;

namespace W8P_Food_식당_관리_시스템
{
    public partial class DUI5003 : Form
    {
        private MySqlConnection connection;
        private MySqlDataAdapter mySqlDataAdapter;
        DUI5002 dui5002;

        public DUI5003(DUI5002 f)
        {
            dui5002 = f;
            InitializeComponent();
        }


        private bool OpenConnection()
        {
            try
            {
                connection.Open();
                return true;
            }
            catch (MySqlException ex)
            {
                switch (ex.Number)
                {
                    case 0:
                        MessageBox.Show("Cannot connect to server. Contact administrator");
                        break;
                    case 1045:
                        MessageBox.Show("Invalid username/password, please try again");
                        break;
                    default:
                        MessageBox.Show(ex.Message);
                        break;
                }
                return false;
            }
        }

        private bool CloseConnection()
        {
            try
            {
                connection.Close();
                return true;
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message);
                return false;
            }
        }

        private void btn_ok_Click(object sender, EventArgs e)
        {
            if (comboBox1.SelectedItem == null || dateTimePicker1.Text == "" || comboBox2.SelectedItem == null)
            {
                MessageBox.Show("[오류] 필수 정보가 입력되지 않았습니다.");
                return;
            }

            if (comboBox2.SelectionLength > 10)
            {
                MessageBox.Show("발주 업체 명 길이는 10 자리 이하로 입력해주세요.");
                return;
            }


            string strConn = "Server=218.233.209.73;Port=10040;Database=w8p_foodmanagement_system;Uid=root;Pwd=scotish1;pooling = false; convert zero datetime=True";
            connection = new MySqlConnection(strConn);

            if (this.OpenConnection() == true)
            {
                InOutLogInfo or = new InOutLogInfo();
                or = dui5002.getInfo();

                or.InOrOut = comboBox1.SelectedItem.ToString();
                or.date = dateTimePicker1.Value;
                or.providerName = comboBox2.SelectedItem.ToString();

                // 쿼리문 작성
                string query = "UPDATE inoutlog SET InOrOut=@InOrOut,date=@date,  providerName=@providerName where id=@id";

                MySqlCommand cmd = new MySqlCommand(query, connection);

                //cmd.Parameters.AddWithValue("@type", or.id);
                cmd.Parameters.AddWithValue("@id", or.id);
                cmd.Parameters.AddWithValue("@InOrOut", or.InOrOut);
                cmd.Parameters.AddWithValue("@date", or.date);
                cmd.Parameters.AddWithValue("@providerName", or.providerName);
                cmd.ExecuteNonQuery();
                this.CloseConnection();

                MessageBox.Show("변경되었습니다.");
                this.Dispose();
            }
        }

        private void btn_cancel_Click(object sender, EventArgs e)
        {
            dui5002.dui5003 = null;
            this.Dispose();
        }

        private void DUI5003_Load(object sender, EventArgs e)
        {
            string strConn = "Server=218.233.209.73;Port=10040;Database=w8p_foodmanagement_system;Uid=root;Pwd=scotish1;pooling = false; convert zero datetime=True";
            connection = new MySqlConnection(strConn);

            if (this.OpenConnection() == true)
            {
                DataTable DTProvider;
                DataTable DTIngredient;

                mySqlDataAdapter = new MySqlDataAdapter("select name from provider", connection);
                DTProvider = new DataTable();
                mySqlDataAdapter.Fill(DTProvider);

                for (int i = 0; i < DTProvider.Rows.Count; i++)
                {
                    DataRow dr = DTProvider.Rows[i];
                    comboBox2.Items.Add(dr["name"].ToString());
                }

                this.CloseConnection();
            }
        }

        private void DUI5003_FormClosed(object sender, FormClosedEventArgs e)
        {
            dui5002.dui5003 = null;
        }
    }
}