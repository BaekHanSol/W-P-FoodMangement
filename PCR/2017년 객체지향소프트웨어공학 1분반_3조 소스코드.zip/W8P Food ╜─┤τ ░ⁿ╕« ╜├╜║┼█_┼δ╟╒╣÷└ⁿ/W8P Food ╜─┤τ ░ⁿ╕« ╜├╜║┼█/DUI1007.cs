using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using MySql.Data.Common;

namespace W8P_Food_�Ĵ�_����_�ý���
{
    public partial class DUI1007 : Form
    {
        private MySqlConnection connection;
        public DUI1006 dui1006;
       
        public DUI1007(DUI1006 f)
        {
            dui1006 = f;
            InitializeComponent();
        }

        private bool OpenConnection()
        {
            try
            {
                connection.Open();
                return true;
            }
            catch (MySqlException ex)
            {
                switch (ex.Number)
                {
                    case 0:
                        MessageBox.Show("Cannot connect to server. Contact administrator");
                        break;
                    case 1045:
                        MessageBox.Show("Invalid username/password, please try again");
                        break;
                    default:
                        MessageBox.Show(ex.Message);
                        break;
                }
                return false;
            }
        }

        private bool CloseConnection()
        {
            try
            {
                connection.Close();
                return true;
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message);
                return false;
            }
        }

        // ����
        private void button1_Click(object sender, EventArgs e)
        {
            // ��ȿ��
            if (!formatCheck())
                return;

            //���� check
            if (textBox1.Text == "")
            {
                MessageBox.Show("�����͸� ��� �Է��ϼ���.");
                return;
            }
            //��ȿ�� check
            else if (Convert.ToDouble(textBox1.Text) < 0 || Convert.ToDouble(textBox1.Text) > 100)
            {
                MessageBox.Show("�ش��ϴ� ���� ���� �� �����ϴ�. (0~100������ ���� �Է����ּ���)");
                textBox1.Text = null;

                return;
            }
            string strConn = "Server=218.233.209.73;Port=10040;Database=w8p_foodmanagement_system;Uid=root;Pwd=scotish1;pooling = false; convert zero datetime=True";
            connection = new MySqlConnection(strConn);

            if (this.OpenConnection() == true)
            {
                Pointsavingratio ps = new Pointsavingratio();
                ps = dui1006.getPoinsavingratioInfo();

                ps.savingRatio = (double)Convert.ToInt32(textBox1.Text);

                // ������ �ۼ�
                string query = "UPDATE pointsavingratio SET savingRatio=@savingRatio WHERE id=@id";
                MySqlCommand cmd = new MySqlCommand(query, connection);

                cmd.Parameters.AddWithValue("@id", ps.id);
                cmd.Parameters.AddWithValue("@savingRatio", ps.savingRatio);
                cmd.ExecuteNonQuery();
                this.CloseConnection();

                this.Dispose();
                MessageBox.Show("��� : " + ps.grade + "/ ������ : " + ps.savingRatio + "%" + "\n���� �Ϸ�");
                return;
            }

            dui1006.dui1007 = null;

        }

        // �ݱ�
        private void button2_Click(object sender, EventArgs e)
        {
            dui1006.dui1007 = null;
            this.Dispose();
        }

        private void DUI1007_Load(object sender, EventArgs e)
        {
            Pointsavingratio pr = new Pointsavingratio();
            pr = dui1006.getPoinsavingratioInfo();

            label3.Text = pr.grade.ToString();
        }

        private bool formatCheck()
        {
            decimal num = 0;
            string amount = textBox1.Text;

            bool isFormatOk1 = decimal.TryParse(amount, out num);


            if (isFormatOk1 == false)
            {
                MessageBox.Show("[����] ������ ��ġ���� �ʽ��ϴ�.");
                return false;
            }

            return true;
        }
    }
}
