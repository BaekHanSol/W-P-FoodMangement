using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using MySql.Data.Common;

namespace W8P_Food_�Ĵ�_����_�ý���
{
    public partial class DUI1001 : Form
    {
        private MySqlConnection connection;
        W8P_Food_Management_System mainform;

        public DUI1001(W8P_Food_Management_System f)
        {
            mainform = f;
            InitializeComponent();
        }
        private bool OpenConnection()
        {
            try
            {
                connection.Open();
                return true;
            }
            catch (MySqlException ex)
            {
                switch (ex.Number)
                {
                    case 0:
                        MessageBox.Show("Cannot connect to server. Contact administrator");
                        break;
                    case 1045:
                        MessageBox.Show("Invalid username/password, please try again");
                        break;
                    default:
                        MessageBox.Show(ex.Message);
                        break;
                }
                return false;
            }
        }

        private bool CloseConnection()
        {
            try
            {
                connection.Close();
                return true;
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message);
                return false;
            }
        }
        private void DUI1001_FormClosing(object sender, FormClosingEventArgs e)
        {
        }

        // ���
        private void button1_Click(object sender, EventArgs e)
        {
            connection.Open();
            string insertValue = dateTimePicker1.Text;

            string mysql = "select nonBusinessDay from businessday where nonBusinessDay='" + insertValue + "'";
            MySqlCommand cmd = new MySqlCommand(mysql,connection);
            MySqlDataReader sr = cmd.ExecuteReader();
            
            //�ߺ� check
            if(sr.HasRows)
            {
                MessageBox.Show("�̹� �����ϴ� �����Դϴ�.");
                sr.Close();
                connection.Close();
                return;
            }
            
                mysql = "INSERT INTO businessday (id, nonBusinessDay) " + "VALUES (LAST_INSERT_ID(), '" + insertValue + "')";
                cmd = new MySqlCommand(mysql, connection);

            sr.Close();
            cmd.ExecuteNonQuery();
            connection.Close();
            mainform.dui1002 = null;
            MessageBox.Show("�񿵾��� : " + insertValue + "\n��� �Ϸ�");
            return;

        }

        // �ݱ�
        private void button2_Click(object sender, EventArgs e)
        {
            mainform.dui1001 = null;
            this.Dispose();
        }

        private void DUI1001_Load(object sender, EventArgs e)
        {
            string strConn = "Server=218.233.209.73;Port=10040;Database=w8p_foodmanagement_system;Uid=root;Pwd=scotish1;pooling = false; convert zero datetime=True";
            connection = new MySqlConnection(strConn);

            if (this.OpenConnection() == true)
            {
                this.CloseConnection();
            }
        }
    }

    
}
