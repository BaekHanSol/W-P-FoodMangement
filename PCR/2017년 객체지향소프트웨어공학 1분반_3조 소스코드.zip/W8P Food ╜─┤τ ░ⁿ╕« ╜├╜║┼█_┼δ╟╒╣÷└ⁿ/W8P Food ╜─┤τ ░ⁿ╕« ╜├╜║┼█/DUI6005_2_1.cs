﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using MySql.Data.Common;

namespace W8P_Food_식당_관리_시스템
{
    public partial class DUI6005_2_1 : Form
    {
        private MySqlConnection connection;
        private MySqlDataAdapter mySqlDataAdapter;
        DUI6005_2 dui6005_2;

        public DUI6005_2_1(DUI6005_2 f)
        {
            dui6005_2 = f;
            InitializeComponent();
        }

        private bool OpenConnection()
        {
            try
            {
                connection.Open();
                return true;
            }
            catch (MySqlException ex)
            {
                switch (ex.Number)
                {
                    case 0:
                        MessageBox.Show("Cannot connect to server. Contact administrator");
                        break;
                    case 1045:
                        MessageBox.Show("Invalid username/password, please try again");
                        break;
                    default:
                        MessageBox.Show(ex.Message);
                        break;
                }
                return false;
            }
        }

        private bool CloseConnection()
        {
            try
            {
                connection.Close();
                return true;
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message);
                return false;
            }
        }

        private bool formatCheck()
        {
            decimal num = 0;
            string amount = txtAmount.Text;
            bool isFormatOk1 = decimal.TryParse(amount, out num);


            if (isFormatOk1 == false)
            {
                MessageBox.Show("[오류] 형식이 일치하지 않습니다.");
                return false;
            }

            return true;
        }
        

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            if(!formatCheck())
            {
                return;
            }

            if (comboIngredient.SelectedItem == null || txtAmount.Text == "")
            {
                MessageBox.Show("데이터를 모두 입력하세요.");
                return;
            }


            string strConn = "Server=218.233.209.73;Port=10040;Database=w8p_foodmanagement_system;Uid=root;Pwd=scotish1;pooling = false; convert zero datetime=True";
            connection = new MySqlConnection(strConn);

            // 발주처 등록
            if (this.OpenConnection() == true)
            {
                ORList or = new ORList();

                or = dui6005_2.getORLInfo();

                or.ingredientName = comboIngredient.SelectedItem.ToString();
                or.amount = Convert.ToInt32(txtAmount.Text);

                // 쿼리문 작성
                string query = "UPDATE orlist SET ingredientName=@ingredientName, amount=@amount WHERE id=@id";
                MySqlCommand cmd = new MySqlCommand(query, connection);

                cmd.Parameters.AddWithValue("@id", or.id);
                cmd.Parameters.AddWithValue("@ingredientName", or.ingredientName);
                cmd.Parameters.AddWithValue("@amount", or.amount);
                cmd.ExecuteNonQuery();
                this.CloseConnection();

                this.Dispose();
            }

            dui6005_2.dui6005_2_1 = null;

        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            dui6005_2.dui6005_2_1 = null;
            this.Dispose();
        }

        private void DUI6005_2_1_Load(object sender, EventArgs e)
        {
            string strConn = "Server=218.233.209.73;Port=10040;Database=w8p_foodmanagement_system;Uid=root;Pwd=scotish1;pooling = false; convert zero datetime=True";
            connection = new MySqlConnection(strConn);

            if (this.OpenConnection() == true)
            {
                DataTable DTIngredient;

                // 식재료 등록
                mySqlDataAdapter = new MySqlDataAdapter("select * from material", connection);
                DTIngredient = new DataTable();
                mySqlDataAdapter.Fill(DTIngredient);

                for (int i = 0; i < DTIngredient.Rows.Count; i++)
                {
                    DataRow dr = DTIngredient.Rows[i];
                    comboIngredient.Items.Add(dr["name"].ToString());
                }

                this.CloseConnection();
            }
        }
    }
}
