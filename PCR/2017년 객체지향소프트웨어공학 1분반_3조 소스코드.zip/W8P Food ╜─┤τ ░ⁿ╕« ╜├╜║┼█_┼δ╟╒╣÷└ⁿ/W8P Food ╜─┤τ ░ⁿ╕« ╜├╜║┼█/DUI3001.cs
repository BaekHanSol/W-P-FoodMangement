﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using MySql.Data.Common;


namespace W8P_Food_식당_관리_시스템
{
    public partial class DUI3001 : Form
    {
        private MySqlConnection connection;
        private MySqlDataAdapter mySqlDataAdapter;
        W8P_Food_Management_System mainform;

        public DUI3001(W8P_Food_Management_System f)
        {
            InitializeComponent();
            mainform = f;

        }

        private bool OpenConnection()
        {
            try
            {
                connection.Open();
                return true;
            }
            catch (MySqlException ex)
            {
                switch (ex.Number)
                {
                    case 0:
                        MessageBox.Show("Cannot connect to server. Contact administrator");
                        break;
                    case 1045:
                        MessageBox.Show("Invalid username/password, please try again");
                        break;
                    default:
                        MessageBox.Show(ex.Message);
                        break;
                }
                return false;
            }
        }

        private bool CloseConnection()
        {
            try
            {
                connection.Close();
                return true;
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message);
                return false;
            }
        }

        private void btnRegister_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private bool formatCheck()
        {
            decimal num = 0;
            string amount = calorieTxt.Text;
            string cookTime = cookTimeTxt.Text;
            string price = priceTxt.Text;

            bool isFormatOk1 = decimal.TryParse(amount, out num);
            bool isFormatOk2 = decimal.TryParse(cookTime, out num);
            bool isFormatOk3 = decimal.TryParse(price, out num);


            if (isFormatOk1 == false || isFormatOk2 == false || isFormatOk3 == false)
            {
                MessageBox.Show("[오류] 형식이 일치하지 않습니다.");
                return false;
            }

            return true;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // 유효성
            if (!formatCheck())
                return;

            if (menuTxt.Text == "" || priceTxt.Text == "" || calorieTxt.Text == "" || cookTimeTxt.Text == "" || dateTimePicker1.Text == "" || dateTimePicker2.Text == "")
            {
                MessageBox.Show("데이터를 모두 입력하세요.");
                return;
            }

            if (menuTxt.TextLength > 10)
            {
                MessageBox.Show("메뉴명의 길이는 10자리 이내로 입력해주세요.");
                return;
            }

            if (priceTxt.TextLength > 11)
            {
                MessageBox.Show("가격의 길이는 11자리 이내로 입력해주세요.");
                return;
            }

            if (calorieTxt.TextLength > 11)
            {
                MessageBox.Show("칼로리의 길이는 11자리 이내로 입력해주세요.");
                return;
            }

            if (cookTimeTxt.TextLength > 11)
            {
                MessageBox.Show("조리시간의 길이는 11자리 이내로 입력해주세요.");
                return;
            }
            string strConn = "Server=218.233.209.73;Port=10040;Database=w8p_foodmanagement_system;Uid=root;Pwd=scotish1;pooling = false; convert zero datetime=True";
            connection = new MySqlConnection(strConn);

            // 발주처 등록
            if (this.OpenConnection() == true)
            {
                MenuInfo mi = new MenuInfo();
                mi.menuName = menuTxt.Text.ToString();
                mi.price = Convert.ToInt32(priceTxt.Text);
                mi.calorie = Convert.ToDouble(calorieTxt.Text);
                mi.cookTime = Convert.ToInt32(cookTimeTxt.Text);
                mi.registration = dateTimePicker1.Value;
                mi.aboitionDate = dateTimePicker2.Value;


                ///////////////////////// 경고 : 테이블에 첫 튜플 존재 X시 오류남!!!(cause: id++이 없으므로)//////////////////////

                // 쿼리문 작성
                string query = "INSERT INTO menu(name, price, calorie, cookTime, registrationDate, aboitionDate )" + "VALUES(@name, @price, @calorie, @cookTime, @registrationDate, @aboitionDate)";
                MySqlCommand cmd = new MySqlCommand(query, connection);

                cmd.Parameters.AddWithValue("@name", mi.menuName);
                cmd.Parameters.AddWithValue("@price", mi.price);
                cmd.Parameters.AddWithValue("@calorie", mi.calorie);
                cmd.Parameters.AddWithValue("@cookTime", mi.cookTime);
                cmd.Parameters.AddWithValue("@registrationDate", mi.registration);
                cmd.Parameters.AddWithValue("@aboitionDate", mi.aboitionDate);

                cmd.ExecuteNonQuery();
                this.CloseConnection();

                mainform.dui3002 = null;
                menuTxt.Text = "";
                priceTxt.Text = "";
                calorieTxt.Text = "";
                cookTimeTxt.Text = "";
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            mainform.dui3001 = null;
            this.Dispose();
        }

        private void comboIngredient_SelectedIndexChanged(object sender, EventArgs e)
        {


        }

        private void DUI3001_Load_1(object sender, EventArgs e)
        {
            string strConn = "Server=218.233.209.73;Port=10040;Database=w8p_foodmanagement_system;Uid=root;Pwd=scotish1;pooling = false; convert zero datetime=True";
            connection = new MySqlConnection(strConn);

        }
    }
}
