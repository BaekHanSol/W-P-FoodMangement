﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace W8P_Food_식당_관리_시스템
{
    public partial class DUI7001 : Form
    {
        private MySqlConnection connection;
        private MySqlDataAdapter mySqlDataAdapter;
        private int totalPrice = 0;
        W8P_Food_Management_System mainform;

        public DUI7001(W8P_Food_Management_System f)
        {
            mainform = f;
            InitializeComponent();
        }

        private void DUI7001_Load(object sender, EventArgs e)
        {
            string strConn = "Server=218.233.209.73;Port=10040;Database=w8p_foodmanagement_system;Uid=root;Pwd=scotish1;pooling = false; convert zero datetime=True";
            connection = new MySqlConnection(strConn);

            if (this.OpenConnection() == true)
            {
                DataTable datatable;

                mySqlDataAdapter = new MySqlDataAdapter("select * from member", connection);
                datatable = new DataTable();
                mySqlDataAdapter.Fill(datatable);

                for (int i = 0; i < datatable.Rows.Count; i++)
                {
                    DataRow dr = datatable.Rows[i];
                    comboPhoneNum.Items.Add(dr["PhoneNum"].ToString());
                }

                this.CloseConnection();
            }
        }

        private void comboBoxTableNum_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (this.OpenConnection() == true)
            {
                string querry = "select menuId, quantity from orderinfo WHERE tableNum=\'" + comboBoxTableNum.Text + "\'";
                MySqlCommand cmd = new MySqlCommand(querry, connection);
                cmd.ExecuteNonQuery();

                MySqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    string menuId = rdr["menuId"].ToString();
                    string quantity = rdr["quantity"].ToString();
                    getTotalPrice(menuId, quantity);
                }

                txtTotalPrice.Text = totalPrice.ToString();
                if (txtTotalPrice.Text == "0")
                    MessageBox.Show("[오류] 주문 정보가 없는 테이블입니다. 다시 선택해주세요!");
            }

            this.CloseConnection();
        }

        private bool OpenConnection()
        {
            try
            {
                connection.Open();
                return true;
            }
            catch (MySqlException ex)
            {
                switch (ex.Number)
                {
                    case 0:
                        MessageBox.Show("Cannot connect to server. Contact administrator");
                        break;
                    case 1045:
                        MessageBox.Show("Invalid username/password, please try again");
                        break;
                    default:
                        MessageBox.Show(ex.Message);
                        break;
                }

                return false;
            }
        }

        private int getTotalPrice(string menuId, string quantity)
        {
            string strConn = "Server=218.233.209.73;Port=10040;Database=w8p_foodmanagement_system;Uid=root;Pwd=scotish1;pooling = false; convert zero datetime=True";
            MySqlConnection connection = new MySqlConnection(strConn);
            connection.Open();

            string querry = "SELECT price FROM menu WHERE id=\'" + menuId + "\'";
            MySqlCommand cmd = new MySqlCommand(querry, connection);
            cmd.ExecuteNonQuery();

            MySqlDataReader rdr = cmd.ExecuteReader();
            rdr.Read();
            string price = rdr["price"].ToString();
            connection.Close();

            totalPrice += Convert.ToInt32(price) * Convert.ToInt32(quantity);
            return totalPrice;
        }

        private bool CloseConnection()
        {
            try
            {
                connection.Close();
                return true;
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message);
                return false;
            }
        }

        private void btnRegister_Click(object sender, EventArgs e)
        {
            if (totalPrice != Convert.ToInt32(txtCash.Text) + Convert.ToInt32(txtCard.Text) + Convert.ToInt32(txtPoint.Text))
            {
                MessageBox.Show("[오류] 금액이 맞지 않습니다.");
                return;
            }

            if (this.OpenConnection() == true && formatCheck() == true)
            {
                string query = "INSERT INTO sales(tableNum, totalPrice, memberPhone, cash, card, point)" + "VALUES(@tableNum, @totalPrice, @memberPhone, @cash, @card, @point)";
                MySqlCommand cmd = new MySqlCommand(query, connection);

                cmd.Parameters.AddWithValue("@tableNum", comboBoxTableNum.Text);
                cmd.Parameters.AddWithValue("@totalPrice", totalPrice);
                cmd.Parameters.AddWithValue("@memberPhone", comboPhoneNum.Text);
                cmd.Parameters.AddWithValue("@cash", txtCash.Text);
                cmd.Parameters.AddWithValue("@card", txtCard.Text);
                cmd.Parameters.AddWithValue("@point", txtPoint.Text);
                cmd.ExecuteNonQuery();

                this.CloseConnection();
            }

            if (comboPhoneNum.Text != "")
            {
                savePoint(comboPhoneNum.Text, txtPoint.Text);
                usePoint(comboPhoneNum.Text, txtPoint.Text);
            }

            string strConn = "Server=218.233.209.73;Port=10040;Database=w8p_foodmanagement_system;Uid=root;Pwd=scotish1;pooling = false; convert zero datetime=True";
            MySqlConnection conn = new MySqlConnection(strConn);
            conn.Open();
            string deleteQuery = "DELETE from orderinfo WHERE tableNum=@tableNum";
            MySqlCommand deleteCmd = new MySqlCommand(deleteQuery, conn);
            deleteCmd.Parameters.AddWithValue("@tableNum", comboBoxTableNum.Text);
            deleteCmd.ExecuteNonQuery();
            conn.Close();
            MessageBox.Show("결제가 완료되었습니다.");

            mainform.dui7002 = null;
            txtCard.Text = "0";
            txtCash.Text = "0";
            txtPoint.Text = "0";
            comboPhoneNum.Text = "";
            comboBoxTableNum.Text = "";
            txtTotalPrice.Text = "";
        }

        private bool formatCheck()
        {
            if(txtCash.TextLength > 15 || txtCard.TextLength > 15 || txtPoint.TextLength > 15)
            {
                MessageBox.Show("[오류] 형식이 일치하지 않습니다.");
                return false;
            }
                
            if(Convert.ToInt32(txtCard.Text) < 0 || Convert.ToInt32(txtCash.Text) < 0 || Convert.ToInt32(txtPoint.Text) < 0)
            {
                MessageBox.Show("[오류] 금액이 잘못되었습니다.");
                return false;
            }

            return true;
        }

        private void savePoint(string memberPhoneNum, string p_point)
        {
            string strConn = "Server=218.233.209.73;Port=10040;Database=w8p_foodmanagement_system;Uid=root;Pwd=scotish1;pooling = false; convert zero datetime=True";
            MySqlConnection conn = new MySqlConnection(strConn);
            conn.Open();

            string querry = "SELECT point FROM member WHERE PhoneNum=\'" + memberPhoneNum + "\'";
            MySqlCommand cmd = new MySqlCommand(querry, conn);
            cmd.ExecuteNonQuery();

            MySqlDataReader rdr = cmd.ExecuteReader();
            rdr.Read();
            int point = Convert.ToInt32(rdr["point"]);

            point += Convert.ToInt32((totalPrice - Convert.ToInt32(p_point)) * 0.05);
            conn.Close();

            MySqlConnection conn1 = new MySqlConnection(strConn);
            conn1.Open();
            querry = "UPDATE member SET point=@point WHERE PhoneNum=@PhoneNum";  // 쿼리 확인
            cmd = new MySqlCommand(querry, conn1);
            cmd.Parameters.AddWithValue("@point", point);
            cmd.Parameters.AddWithValue("@PhoneNum", memberPhoneNum);
            cmd.ExecuteNonQuery();
            conn1.Close();
        }

        private void usePoint(string memberPhoneNum, string p_point)
        {
            string strConn = "Server=218.233.209.73;Port=10040;Database=w8p_foodmanagement_system;Uid=root;Pwd=scotish1;pooling = false; convert zero datetime=True";
            MySqlConnection conn = new MySqlConnection(strConn);
            conn.Open();

            string querry = "SELECT point FROM member WHERE PhoneNum=\'" + memberPhoneNum + "\'";
            MySqlCommand cmd = new MySqlCommand(querry, conn);
            cmd.ExecuteNonQuery();

            MySqlDataReader rdr = cmd.ExecuteReader();
            rdr.Read();
            int point = Convert.ToInt32(rdr["point"]);
            point -= Convert.ToInt32(p_point);
            conn.Close();

            MySqlConnection conn1 = new MySqlConnection(strConn);
            conn1.Open();
            querry = "UPDATE member SET point=@point WHERE PhoneNum=@PhoneNum";
            cmd = new MySqlCommand(querry, conn1);
            cmd.Parameters.AddWithValue("@point", point);
            cmd.Parameters.AddWithValue("@PhoneNum", memberPhoneNum);
            cmd.ExecuteNonQuery();
            conn1.Close();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            mainform.dui7001 = null;
            this.Dispose();
        }

        private void txtCash_TextChanged(object sender, EventArgs e)
        {
            decimal num = 0;
            bool isFormatOk = decimal.TryParse(txtCash.Text, out num);

            if (isFormatOk == false)
                MessageBox.Show("[오류] 숫자를 입력해주세요.");
        }

        private void txtCard_TextChanged(object sender, EventArgs e)
        {
            decimal num = 0;
            bool isFormatOk = decimal.TryParse(txtCard.Text, out num);

            if (isFormatOk == false)
                MessageBox.Show("[오류] 숫자를 입력해주세요.");

        }

        private void txtPoint_TextChanged(object sender, EventArgs e)
        {
            decimal num = 0;
            bool isFormatOk = decimal.TryParse(txtPoint.Text, out num);

            if (isFormatOk == false)
                MessageBox.Show("[오류] 숫자를 입력해주세요.");
        }
    }
}