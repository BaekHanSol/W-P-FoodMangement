﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using MySql.Data.Common;

namespace W8P_Food_식당_관리_시스템
{
    public partial class DUI5001 : Form
    {
        private MySqlConnection connection;
        private MySqlDataAdapter mySqlDataAdapter;
        W8P_Food_Management_System mainform;

        public DUI5001(W8P_Food_Management_System f)
        {
            mainform = f;
            //timer1.Start();
            InitializeComponent();
        }

        private void label7_Click(object sender, EventArgs e)
        {

        }


        private bool OpenConnection()
        {
            try
            {
                connection.Open();
                return true;
            }
            catch (MySqlException ex)
            {
                switch (ex.Number)
                {
                    case 0:
                        MessageBox.Show("Cannot connect to server. Contact administrator");
                        break;
                    case 1045:
                        MessageBox.Show("Invalid username/password, please try again");
                        break;
                    default:
                        MessageBox.Show(ex.Message);
                        break;
                }
                return false;
            }

        }

        private bool CloseConnection()
        {
            try
            {
                connection.Close();
                return true;
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message);
                return false;
            }
        }

        private void DUI5001_Load(object sender, EventArgs e)
        {
            string strConn = "Server=218.233.209.73;Port=10040;Database=w8p_foodmanagement_system;Uid=root;Pwd=scotish1;pooling = false; convert zero datetime=True";
            connection = new MySqlConnection(strConn);

            if (this.OpenConnection() == true)
            {
                DataTable DTProvider;
                DataTable DTIngredient;

                mySqlDataAdapter = new MySqlDataAdapter("select name from provider", connection);
                DTProvider = new DataTable();
                mySqlDataAdapter.Fill(DTProvider);

                for (int i = 0; i < DTProvider.Rows.Count; i++)
                {
                    DataRow dr = DTProvider.Rows[i];
                    comboProvider.Items.Add(dr["name"].ToString());
                }



                // 식재료 등록
                mySqlDataAdapter = new MySqlDataAdapter("select * from material", connection);
                DTIngredient = new DataTable();
                mySqlDataAdapter.Fill(DTIngredient);

                for (int i = 0; i < DTIngredient.Rows.Count; i++)
                {
                    DataRow dr = DTIngredient.Rows[i];
                    com_material.Items.Add(dr["name"].ToString());
                }

                this.CloseConnection();


            }
        }

        private void btn_regist_Click(object sender, EventArgs e)
        {
            if (essentialCheck() == true && formatCheck() == true)
            {
                if (com_material.SelectionLength > 20)
                {
                    MessageBox.Show("식자재 명의 길이는 20 자리 이하로 입력해주세요.");
                    return;
                }
                if (textBox3.TextLength > 20)
                {
                    MessageBox.Show("원산지의 길이는 20 자리 이하로 입력해주세요.");
                    return;
                }
                if (textBox2.TextLength > 20)
                {
                    MessageBox.Show("입고시 상태의 길이는 20 자리 이하로 입력해주세요.");
                    return;
                }
                if (textBox5.TextLength > 2)
                {
                    MessageBox.Show("보관장소 습도 길이는 2 자리 이하로 입력해주세요.");
                    return;
                }
                if (textBox4.TextLength > 3)
                {
                    MessageBox.Show("보관장소 온도의 길이는 3 자리 이하로 입력해주세요.");
                    return;
                }
                if (textBox7.TextLength > 5)
                {
                    MessageBox.Show("단위의 길이는 3 자리 이하로 입력해주세요.");
                    return;
                }

                if (txtAmount.TextLength > 10)
                {
                    MessageBox.Show("수량의 길이는 10 자리 이하로 입력해주세요.");
                    return;
                }
                if (textBox9.TextLength > 10)
                {
                    MessageBox.Show("최소 유지수량의 길이는 10 자리 이하로 입력해주세요.");
                    return;
                }
                if (textBox8.TextLength > 10)
                {
                    MessageBox.Show("최장 저장기간 길이는 10 자리 이하로 입력해주세요.");
                    return;
                }
                if (comboProvider.SelectionLength > 10)
                {
                    MessageBox.Show("발주 업체 명 길이는 10 자리 이하로 입력해주세요.");
                    return;
                }


                for (int i = 0; i < listView1.Items.Count; i++)
                {
                    string str = listView1.Items[i].Text;

                    if (com_material.SelectedItem.ToString().Equals(str) == true)
                    {
                        int sum = 0;
                        sum = Convert.ToInt32(listView1.Items[i].SubItems[1].Text);
                        sum += Convert.ToInt32(txtAmount.Text);

                        listView1.Items.Remove(listView1.Items[i]);

                        ListViewItem listitem2 = new ListViewItem(com_material.SelectedItem.ToString());
                        listitem2.SubItems.Add(sum.ToString());
                        listitem2.SubItems.Add(textBox2.Text.ToString());
                        listitem2.SubItems.Add(textBox4.Text.ToString());
                        listitem2.SubItems.Add(textBox5.Text.ToString());
                        listitem2.SubItems.Add(textBox7.Text.ToString());
                        listitem2.SubItems.Add(textBox3.Text.ToString());
                        listitem2.SubItems.Add(textBox8.Text.ToString());
                        listitem2.SubItems.Add(textBox9.Text.ToString());
                        listView1.Items.Add(listitem2);

                        return;
                    }
                }

                ListViewItem listitem = new ListViewItem(com_material.SelectedItem.ToString());
                listitem.SubItems.Add(txtAmount.Text.ToString());
                listitem.SubItems.Add(textBox2.Text.ToString());
                listitem.SubItems.Add(textBox4.Text.ToString());
                listitem.SubItems.Add(textBox5.Text.ToString());
                listitem.SubItems.Add(textBox7.Text.ToString());
                listitem.SubItems.Add(textBox3.Text.ToString());
                listitem.SubItems.Add(textBox8.Text.ToString());
                listitem.SubItems.Add(textBox9.Text.ToString());
                listView1.Items.Add(listitem);
            }
        }

        private void btn_delete_Click(object sender, EventArgs e)
        {
            if (listView1.SelectedItems.Count != 0)
                listView1.Items.Remove(listView1.SelectedItems[0]);
        }

        // 등록
        private void btn_ok_Click(object sender, EventArgs e)
        {
            string strConn = "Server=218.233.209.73;Port=10040;Database=w8p_foodmanagement_system;Uid=root;Pwd=scotish1;pooling = false; convert zero datetime=True";
            connection = new MySqlConnection(strConn);
            if (this.OpenConnection() == true)
            {
                InOutLogInfo or = new InOutLogInfo();

                or.InOrOut = com_type.SelectedItem.ToString();
                or.name = com_material.SelectedItem.ToString();
                or.amount = Convert.ToInt32(txtAmount.Text);
                or.date = dateTimePicker2.Value;
                or.providerName = comboProvider.SelectedItem.ToString();

                ///////////////////////// 경고 : 테이블에 첫 튜플 존재 X시 오류남!!!(cause: id++이 없으므로)//////////////////////

                string query3 = "select amount from material where name=@name";
                MySqlCommand cmd3 = new MySqlCommand(query3, connection);

                cmd3.Parameters.AddWithValue("@name", or.name);
                cmd3.Parameters.AddWithValue("@amount", or.amount);
                cmd3.ExecuteNonQuery();
                MySqlDataReader rdr = cmd3.ExecuteReader();

                int sum = 0;
                while (rdr.Read())
                {
                    string s = rdr["amount"].ToString();
                    sum = Int32.Parse(s);
                    break;
                }
                if (com_type.Text == "입고")
                {
                    sum += Convert.ToInt32(txtAmount.Text);
                }

                else if (com_type.Text == "출고")
                {
                    string Num = txtAmount.Text;
                    int releaseNum = Convert.ToInt32(Num);
                    if (sum < releaseNum)
                    {
                        MessageBox.Show("출고할 식자재가 부족 합니다.");
                        return;
                    }

                    else if (sum > releaseNum)
                    {
                        sum -= Convert.ToInt32(txtAmount.Text);
                    }
                }

                rdr.Close();

                // 쿼리문 작성
                string query = "INSERT INTO inoutlog(InOrOut, date, providerName)" + "VALUES(@InOrOut, @date, @providerName)";
                MySqlCommand cmd = new MySqlCommand(query, connection);

                //cmd.Parameters.AddWithValue("@type", or.id);
                cmd.Parameters.AddWithValue("@InOrOut", or.InOrOut);
                cmd.Parameters.AddWithValue("@date", or.date);
                cmd.Parameters.AddWithValue("@providerName", or.providerName);
                cmd.ExecuteNonQuery();
                MessageBox.Show("등록되었습니다.");

                string query2 = "UPDATE material SET name=@name,amount=@amount where name=@name";
                MySqlCommand cmd2 = new MySqlCommand(query2, connection);

                cmd2.Parameters.AddWithValue("@name", or.name);
                cmd2.Parameters.AddWithValue("@amount", sum);

                cmd2.ExecuteNonQuery();
                this.CloseConnection();

            }

            mainform.dui5002 = null;
            comboProvider.Text = "";
            com_material.Text = "";
            com_type.Text = "";
            txtAmount.Text = "";
            textBox3.Text = "";
            this.textBox2.Text = "";
            textBox5.Text = "";
            this.textBox7.Text = "";
            this.textBox8.Text = "";
            this.textBox9.Text = "";

            for (int i = 0; i < listView1.Items.Count; i++)
                listView1.Items.Remove(listView1.Items[i]);
        }

        private void btn_cancel_Click(object sender, EventArgs e)
        {
            mainform.dui5001 = null;
            this.Dispose();
        }

        private void com_material_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void timer1_Tick(object sender, EventArgs e)
        {

        }

        private bool essentialCheck()
        {
            if (txtAmount.Text == "" || textBox2.Text == "" || textBox4.Text == "" || textBox5.Text == "" || textBox5.Text == "" || textBox7.Text == "" || textBox3.Text == "" || textBox8.Text == "" || textBox9.Text == "" || comboProvider.SelectedItem == null || dateTimePicker2.Text == "")
            {
                MessageBox.Show("[오류] 필수 정보가 입력되지 않았습니다.");
                return false;
            }

            return true;
        }

        private bool formatCheck()
        {
            decimal num = 0;
            string amount = txtAmount.Text;
            string huminity = textBox5.Text;
            string temperature = textBox4.Text;
            string minQuantity = textBox9.Text;
            bool isFormatOk1 = decimal.TryParse(amount, out num);
            bool isFormatOk2 = decimal.TryParse(huminity, out num);
            bool isFormatOk3 = decimal.TryParse(temperature, out num);
            bool isFormatOk4 = decimal.TryParse(minQuantity, out num);


            if (isFormatOk1 == false || isFormatOk2 == false || isFormatOk3 == false || isFormatOk4 == false)
            {
                MessageBox.Show("[오류] 형식이 일치하지 않습니다.");
                return false;
            }

            return true;
        }

    }
}