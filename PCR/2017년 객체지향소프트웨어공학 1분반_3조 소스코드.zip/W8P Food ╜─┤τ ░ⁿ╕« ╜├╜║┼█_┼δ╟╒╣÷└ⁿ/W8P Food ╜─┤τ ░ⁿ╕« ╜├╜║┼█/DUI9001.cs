﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using MySql.Data.Common;

namespace W8P_Food_식당_관리_시스템
{
    public partial class DUI9001 : Form
    {
        private MySqlConnection connection;
        private MySqlDataAdapter mySqlDataAdapter;
        W8P_Food_Management_System mainform;
        public DUI9001(W8P_Food_Management_System f)
        {
            mainform = f;
            InitializeComponent();
        }
        private bool OpenConnection()
        {
            try
            {
                connection.Open();
                return true;
            }
            catch (MySqlException ex)
            {
                switch (ex.Number)
                {
                    case 0:
                        MessageBox.Show("Cannot connect to server. Contact administrator");
                        break;
                    case 1045:
                        MessageBox.Show("Invalid username/password, please try again");
                        break;
                    default:
                        MessageBox.Show(ex.Message);
                        break;
                }
                return false;
            }
        }
        private bool CloseConnection()
        {
            try
            {
                connection.Close();
                return true;
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message);
                return false;
            }
        }
        private void button2_Click(object sender, EventArgs e)
        {
            mainform.dui9001 = null;
            this.Visible = false;
        }
        
        private void button1_Click(object sender, EventArgs e)
        {
            string mid = MemberId.Text;
            int numChk = 0; ;
            bool isnum = int.TryParse(mid, out numChk);
            if (MemberId.Text == "")
            {
                MessageBox.Show("데이터를 모두 입력하세요.");
                return;
            }
            if(!isnum)
            {
                MessageBox.Show("회원번호에는 숫자이외는 올수 없습니다.");
                return;
            }

            string strConn = "Server=218.233.209.73;Port=10040;Database=w8p_foodmanagement_system;Uid=root;Pwd=scotish1;pooling = false; convert zero datetime=True";
            connection = new MySqlConnection(strConn);
            // 예약 등록
            if (this.OpenConnection() == true)
            {
                ReservationInfo ri = new ReservationInfo();

                ri.MemberId = Convert.ToInt32(MemberId.Text);
                ri.PersonNum = Convert.ToInt32(PersonNum.Text);
                ri.tableNum = Convert.ToInt32(tableNum.Text);
                ri.ReserveDate = ReserveDate.Value;

                
                string str = "SELECT id from member where id=@id";
                MySqlCommand cm = new MySqlCommand(str, connection);

                cm.Parameters.AddWithValue("@id", ri.MemberId);
                MySqlDataReader sr = cm.ExecuteReader();

                if (!sr.HasRows)
                {
                    // 중복데이터가 있는 경우
                    MessageBox.Show("존재하지 않는 회원입니다.");
                    return;
                }
                cm.Dispose();

                // 쿼리문 작성
                String query = "INSERT INTO reservation(tableNum,memberId, date, personNum)" + "VALUES(@tableNum,@memberId,@date,@personNum)";
                MySqlCommand cmd = new MySqlCommand(query, connection);

                cmd.Parameters.AddWithValue("@tableNum", ri.tableNum);
                cmd.Parameters.AddWithValue("@memberId", ri.MemberId);
                cmd.Parameters.AddWithValue("@date", ri.ReserveDate);
                cmd.Parameters.AddWithValue("@personNum", ri.PersonNum);
                cmd.ExecuteNonQuery();
                //mainform.dui9002.resetDataSheet();
                this.CloseConnection();
                finish();
            }
        }
        public void finish()
        {
            MessageBox.Show("등록이 완료되었습니다. ");
            MemberId.Text = "";
            tableNum.Value = 1;
            PersonNum.Value = 1;
            ReserveDate.Value = DateTime.Now;

        }

        private void DUI9001_Load(object sender, EventArgs e)
        {
            MemberId.Text = "";
            tableNum.Value = 1;
            PersonNum.Value = 1;
            ReserveDate.Value = DateTime.Now;
        }
    }
}
