﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using MySql.Data.Common;

namespace W8P_Food_식당_관리_시스템
{
    public partial class DUI5006 : Form
    {
        private MySqlConnection connection;
        private MySqlDataAdapter mySqlDataAdapter;
        DUI5005 dui5005;

        public DUI5006(DUI5005 f)
        {
            dui5005 = f;
            InitializeComponent();
        }

        private void DUI5006_Load(object sender, EventArgs e)
        {
            string strConn = "Server=218.233.209.73;Port=10040;Database=w8p_foodmanagement_system;Uid=root;Pwd=scotish1;pooling = false; convert zero datetime=True";
            connection = new MySqlConnection(strConn);

            if (this.OpenConnection() == true)
            {
                DataTable DTProvider;
                DataTable DTIngredient;

                mySqlDataAdapter = new MySqlDataAdapter("select * from material", connection);
                DTIngredient = new DataTable();
                mySqlDataAdapter.Fill(DTIngredient);

                for (int i = 0; i < DTIngredient.Rows.Count; i++)
                {
                    DataRow dr = DTIngredient.Rows[i];
                    comboBox1.Items.Add(dr["name"].ToString());
                }

                this.CloseConnection();
            }
        }
        private bool OpenConnection()
        {
            try
            {
                connection.Open();
                return true;
            }
            catch (MySqlException ex)
            {
                switch (ex.Number)
                {
                    case 0:
                        MessageBox.Show("Cannot connect to server. Contact administrator");
                        break;
                    case 1045:
                        MessageBox.Show("Invalid username/password, please try again");
                        break;
                    default:
                        MessageBox.Show(ex.Message);
                        break;
                }
                return false;
            }
        }

        private bool CloseConnection()
        {
            try
            {
                connection.Close();
                return true;
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message);
                return false;
            }
        }

        private void btn_ok_Click(object sender, EventArgs e)
        {
            if (comboBox1.SelectedItem == null || dateTimePicker1.Text == "" || textBox1.Text == null || textBox2.Text == null)
            {
                MessageBox.Show("[오류] 필수 정보가 입력되지 않았습니다.");
                return;
            }

            decimal n = 0;

            string q = textBox1.Text;

            bool isFormatOk1 = decimal.TryParse(q, out n);



            if (isFormatOk1 == false)
            {
                MessageBox.Show("[오류] 형식이 일치하지 않습니다.");
                return;
            }


            if (comboBox1.SelectionLength > 20)
            {
                MessageBox.Show("폐기 항목의 길이는 20 자리 이하로 입력해주세요.");
                return;
            }

            if (textBox1.TextLength > 20)
            {
                MessageBox.Show("폐기량의 길이는 10 자리 이하로 입력해주세요.");
                return;
            }

            if (textBox2.TextLength > 20)
            {
                MessageBox.Show("폐기사유의 길이는310 자리 이하로 입력해주세요.");
                return;
            }


            string strConn = "Server=218.233.209.73;Port=10040;Database=w8p_foodmanagement_system;Uid=root;Pwd=scotish1;pooling = false; convert zero datetime=True";
            connection = new MySqlConnection(strConn);

            if (this.OpenConnection() == true)
            {
                IngredientsDisuse or = new IngredientsDisuse();
                or = dui5005.getInfo();

                or.ingredientsName = comboBox1.SelectedItem.ToString();
                or.quantity = Convert.ToInt32(textBox1.Text);
                or.Date = (DateTime)(dateTimePicker1.Value);
                or.reason = textBox2.Text;

                // 쿼리문 작성

                string query3 = "select amount from material where name=@name";
                MySqlCommand cmd3 = new MySqlCommand(query3, connection);

                cmd3.Parameters.AddWithValue("@name", or.ingredientsName);
                cmd3.Parameters.AddWithValue("@amount", or.quantity);
                cmd3.ExecuteNonQuery();
                MySqlDataReader rdr = cmd3.ExecuteReader();

                int sum = 0;
                while (rdr.Read())
                {
                    string s = rdr["amount"].ToString();
                    sum = Int32.Parse(s);
                    break;
                }
                rdr.Close();

                string query = "UPDATE ingredientsdisuse SET ingredientsName=@ingredientsName,quantity=@quantity,  Date=@Date, reason=@reason where id=@id";

                MySqlCommand cmd = new MySqlCommand(query, connection);

                //cmd.Parameters.AddWithValue("@type", or.id);
                cmd.Parameters.AddWithValue("@id", or.id);
                cmd.Parameters.AddWithValue("@ingredientsName", or.ingredientsName);
                cmd.Parameters.AddWithValue("@quantity", or.quantity);
                cmd.Parameters.AddWithValue("@Date", or.Date);
                cmd.Parameters.AddWithValue("@reason", or.reason);
                cmd.ExecuteNonQuery();

                string query4 = "select quantity from ingredientsdisuse where id=@id";
                MySqlCommand cmd4 = new MySqlCommand(query4, connection);

                cmd4.Parameters.AddWithValue("@id", or.id);
                cmd4.Parameters.AddWithValue("@amount", or.quantity);
                cmd4.ExecuteNonQuery();
                MySqlDataReader rdr2 = cmd4.ExecuteReader();

                int num = 0;
                while (rdr2.Read())
                {
                    string s = rdr2["quantity"].ToString();
                    num = Int32.Parse(s);
                    break;
                }
                rdr2.Close();

                sum = sum + dui5005.datagrQ - num;

                string query5 = "UPDATE material SET name=@name,amount=@amount where name=@name";
                MySqlCommand cmd5 = new MySqlCommand(query5, connection);

                cmd5.Parameters.AddWithValue("@name", or.ingredientsName);
                cmd5.Parameters.AddWithValue("@amount", sum);

                cmd5.ExecuteNonQuery();

                this.CloseConnection();

                MessageBox.Show("수정이 완료 되었습니다.");
                this.Dispose();
            }
        }

        private void btn_cancel_Click(object sender, EventArgs e)
        {
            dui5005.dui5006 = null;
            this.Dispose();
        }

        private void DUI5006_FormClosed(object sender, FormClosedEventArgs e)
        {
            dui5005.dui5006 = null;
        }
    }
}