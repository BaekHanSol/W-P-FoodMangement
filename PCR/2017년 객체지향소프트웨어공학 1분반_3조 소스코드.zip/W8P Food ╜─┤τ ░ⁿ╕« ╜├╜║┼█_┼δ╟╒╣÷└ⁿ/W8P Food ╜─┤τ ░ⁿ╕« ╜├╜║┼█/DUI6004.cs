﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using MySql.Data.Common;

namespace W8P_Food_식당_관리_시스템
{
    public partial class DUI6004 : Form
    {
        private MySqlConnection connection;
        private MySqlDataAdapter mySqlDataAdapter;
        W8P_Food_Management_System mainform;


        public DUI6004(W8P_Food_Management_System f)
        {
            mainform = f;
            InitializeComponent();
        }

        private bool OpenConnection()
        {
            try
            {
                connection.Open();
                return true;
            }
            catch (MySqlException ex)
            {
                switch (ex.Number)
                {
                    case 0:
                        MessageBox.Show("Cannot connect to server. Contact administrator");
                        break;
                    case 1045:
                        MessageBox.Show("Invalid username/password, please try again");
                        break;
                    default:
                        MessageBox.Show(ex.Message);
                        break;
                }
                return false;
            }
        }

        private bool CloseConnection()
        {
            try
            {
                connection.Close();
                return true;
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message);
                return false;
            }
        }

        private void DUI6004_Load(object sender, EventArgs e)
        {
            string strConn = "Server=218.233.209.73;Port=10040;Database=w8p_foodmanagement_system;Uid=root;Pwd=scotish1;pooling = false; convert zero datetime=True";
            connection = new MySqlConnection(strConn);
            
            // 발주처 등록
            if (this.OpenConnection() == true)
            {
                DataTable DTProvider;
                DataTable DTIngredient;

                mySqlDataAdapter = new MySqlDataAdapter("select name from provider", connection);
                DTProvider = new DataTable();
                mySqlDataAdapter.Fill(DTProvider);
                
                for(int i = 0; i < DTProvider.Rows.Count; i++)
                {
                    DataRow dr = DTProvider.Rows[i];
                    comboProvider.Items.Add(dr["name"].ToString());
                }

                /*
                string[] items = new string[DT.Rows.Count];
                for (int i = 0; i < DT.Rows.Count; i++)
                {
                    DataRow dr = DT.Rows[i];
                    items[i] = dr["name"].ToString();
                }
                comboProvider.Items.AddRange(items);
                */

                // 식재료 등록
                mySqlDataAdapter = new MySqlDataAdapter("select * from material", connection);
                DTIngredient = new DataTable();
                mySqlDataAdapter.Fill(DTIngredient);

                for (int i = 0; i < DTIngredient.Rows.Count; i++)
                {
                    DataRow dr = DTIngredient.Rows[i];
                    comboIngredient.Items.Add(dr["name"].ToString());
                }

                this.CloseConnection();
            }
        }

        // 식재료 등록
        private void btnRegister_Click(object sender, EventArgs e)
        {
            for(int i = 0; i < listView1.Items.Count; i++)
            {
                string str = listView1.Items[i].Text;

                if (comboIngredient.SelectedItem.ToString().Equals(str) == true)
                {
                    int sum = 0;
                    sum = Convert.ToInt32(listView1.Items[i].SubItems[1].Text);
                    sum += Convert.ToInt32(txtAmount.Text);

                    listView1.Items.Remove(listView1.Items[i]);

                    ListViewItem listitem2 = new ListViewItem(comboIngredient.SelectedItem.ToString());
                    listitem2.SubItems.Add(sum.ToString());
                    listView1.Items.Add(listitem2);

                    return;
                }
            }

            ListViewItem listitem = new ListViewItem(comboIngredient.SelectedItem.ToString());
            listitem.SubItems.Add(txtAmount.Text.ToString());
            listView1.Items.Add(listitem);
        }

        // 식재료 제거
        private void btnDelete_Click(object sender, EventArgs e)
        {
            if(listView1.SelectedItems.Count != 0)
                listView1.Items.Remove(listView1.SelectedItems[0]);
        }

        private bool formatCheck()
        {
            decimal num = 0;
            string amount = txtAmount.Text;
            string price = txtPrice.Text;
            bool isFormatOk1 = decimal.TryParse(amount, out num);
            bool isFormatOk2 = decimal.TryParse(price, out num);


            if (isFormatOk1 == false || isFormatOk2 == false)
            {
                MessageBox.Show("[오류] 형식이 일치하지 않습니다.");
                return false;
            }

            return true;
        }

        // 발주 정보 등록
        private void OK_Click(object sender, EventArgs e)
        {
            if(!formatCheck())
            {
                return;
            }

            if (comboProvider.SelectedItem == null || comboType.SelectedItem == null || txtPrice.Text == "")
            {
                MessageBox.Show("데이터를 모두 입력하세요.");
                return;
            }

            string strConn = "Server=218.233.209.73;Port=10040;Database=w8p_foodmanagement_system;Uid=root;Pwd=scotish1;pooling = false; convert zero datetime=True";
            connection = new MySqlConnection(strConn);
            
            // 발주처 등록
            if (this.OpenConnection() == true)
            {
                OrderReturnInfo or = new OrderReturnInfo();

                or.provider = comboProvider.SelectedItem.ToString();
                or.type = comboType.SelectedItem.ToString();
                or.date = (DateTime)(dateTimePicker1.Value); 
                or.price = Convert.ToInt32(txtPrice.Text);

                ///////////////////////// 경고 : 테이블에 첫 튜플 존재 X시 오류남!!!(cause: id++이 없으므로)//////////////////////

                // 쿼리문 작성
                string query = "INSERT INTO orderreturn(type, provider, date, price)" + "VALUES(@type, @provider, @date, @price)";
                MySqlCommand cmd = new MySqlCommand(query, connection);

                cmd.Parameters.AddWithValue("@type", or.type);
                cmd.Parameters.AddWithValue("@provider", or.provider);
                cmd.Parameters.AddWithValue("@date", or.date);
                cmd.Parameters.AddWithValue("@price", or.price);
                cmd.ExecuteNonQuery();

                query = "select id from orderreturn where (type=@type, provider=@provider, date=@date, price=@price)";
                cmd = new MySqlCommand(query, connection);

                cmd.Parameters.AddWithValue("@type", or.type);
                cmd.Parameters.AddWithValue("@provider", or.provider);
                cmd.Parameters.AddWithValue("@date", or.date);
                cmd.Parameters.AddWithValue("@price", or.price);

                ORList orl = new ORList();

                cmd.CommandText = "SELECT LAST_INSERT_ID()";
                IDataReader reader = cmd.ExecuteReader();

                int ORid = 0;
                if (reader != null && reader.Read())
                {
                    ORid = reader.GetInt32(0);
                }

                reader.Close();

                // int ORid = Convert.ToInt32(cmd.LastInsertedId);

                for (int i = 0; i < listView1.Items.Count; i++)
                {
                    orl.ORId = ORid;
                    orl.ingredientName = listView1.Items[i].Text;
                    orl.amount = Convert.ToInt32(listView1.Items[i].SubItems[1].Text);

                    query = "INSERT INTO orlist(ORId, ingredientName, amount)" + "VALUES(@ORId, @ingredientName, @amount)";
                    cmd = new MySqlCommand(query, connection);

                    cmd.Parameters.AddWithValue("@ORId", orl.ORId);
                    cmd.Parameters.AddWithValue("@ingredientName", orl.ingredientName);
                    cmd.Parameters.AddWithValue("@amount", orl.amount);
                    cmd.ExecuteNonQuery();
                }

                this.CloseConnection();
            }

            mainform.dui6005 = null;
            txtAmount.Text = "";
            txtPrice.Text = "";
            comboIngredient.Text = "";
            comboProvider.Text = "";
            comboType.Text = "";
            listView1.Items.Clear();
        }

        // 닫기
        private void CANCEL_Click(object sender, EventArgs e)
        {
            mainform.dui6004 = null;
            this.Dispose();
        }











        /// 잘못된것들
        private void comboIngredient_SelectedIndexChanged(object sender, EventArgs e)
        {
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

    }
}
