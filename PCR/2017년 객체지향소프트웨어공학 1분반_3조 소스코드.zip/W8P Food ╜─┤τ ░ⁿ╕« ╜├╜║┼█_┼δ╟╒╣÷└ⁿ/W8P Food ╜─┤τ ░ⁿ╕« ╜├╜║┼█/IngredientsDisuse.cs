﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace W8P_Food_식당_관리_시스템
{
    public class IngredientsDisuse
    {

        public int id;
        public string ingredientsName;
        public int quantity;
        public DateTime Date;
        public string reason;
    }
}
