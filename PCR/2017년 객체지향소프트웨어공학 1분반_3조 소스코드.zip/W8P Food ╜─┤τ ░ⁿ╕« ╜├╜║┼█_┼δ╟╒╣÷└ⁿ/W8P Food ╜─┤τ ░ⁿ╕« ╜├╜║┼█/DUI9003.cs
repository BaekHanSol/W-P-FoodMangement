﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using MySql.Data.Common;

namespace W8P_Food_식당_관리_시스템
{
    public partial class DUI9003 : Form
    {
        private MySqlConnection connection;
        private MySqlDataAdapter mySqlDataAdapter;
        DUI9002 dui9002;
        public DUI9003(DUI9002 f)
        {
            dui9002 = f;
            InitializeComponent();
        }
        private bool OpenConnection()
        {
            try
            {
                connection.Open();
                return true;
            }
            catch (MySqlException ex)
            {
                switch (ex.Number)
                {
                    case 0:
                        MessageBox.Show("Cannot connect to server. Contact administrator");
                        break;
                    case 1045:
                        MessageBox.Show("Invalid username/password, please try again");
                        break;
                    default:
                        MessageBox.Show(ex.Message);
                        break;
                }
                return false;
            }
        }

        private bool CloseConnection()
        {
            try
            {
                connection.Close();
                return true;
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message);
                return false;
            }
        }

        private void DUI9003_Load(object sender, EventArgs e)
        {
            this.Visible = true;
            ReservationInfo ri = new ReservationInfo();
            ri = dui9002.getInfo();
            reserveNum.Text = Convert.ToString(ri.ReserveId);
            Memberid.Text = Convert.ToString(ri.MemberId);
            tablenum.Text = Convert.ToString(ri.tableNum);
            Personnum.Text = Convert.ToString(ri.PersonNum);
            date.Value = ri.ReserveDate;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            dui9002.dui9003 = null;
            this.Visible=false;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (Memberid.Text == "")
            {
                MessageBox.Show("데이터를 모두 입력하세요.");
                return;
            }
            string strConn = "Server=218.233.209.73;Port=10040;Database=w8p_foodmanagement_system;Uid=root;Pwd=scotish1;pooling = false; convert zero datetime=True";
            connection = new MySqlConnection(strConn);

            if (this.OpenConnection() == true)
            {
                ReservationInfo ri = new ReservationInfo();
                ri = dui9002.getInfo();

                ri.tableNum = Convert.ToInt32(tablenum.Value);
                ri.PersonNum = Convert.ToInt32(Personnum.Value);
                ri.ReserveDate = date.Value;
                ri.ReserveId = Convert.ToInt32(reserveNum.Text);
                ri.MemberId = Convert.ToInt32(Memberid.Text);

                // 쿼리문 작성
                string query = "UPDATE reservation SET tableNum=@tableNum, date=@date, personNum=@personNum WHERE id=@id";
                MySqlCommand cmd = new MySqlCommand(query, connection);

                cmd.Parameters.AddWithValue("@tableNum", ri.tableNum);
                cmd.Parameters.AddWithValue("@date", ri.ReserveDate);
                cmd.Parameters.AddWithValue("@personNum", ri.PersonNum);                
                cmd.Parameters.AddWithValue("@id", ri.ReserveId);
                cmd.ExecuteNonQuery();
                this.CloseConnection();

                this.Visible = false;
            }
        }
    }
}
