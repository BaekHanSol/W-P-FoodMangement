﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace W8P_Food_식당_관리_시스템
{
    public class ProviderInfo
    {
        public string name;
        public string phone;
        public string address;
        public string registrationNum;
        public string chargerName;
        public string chargerNum;
        public DateTime constractDate;
        public DateTime expirationDate;
    }
}
