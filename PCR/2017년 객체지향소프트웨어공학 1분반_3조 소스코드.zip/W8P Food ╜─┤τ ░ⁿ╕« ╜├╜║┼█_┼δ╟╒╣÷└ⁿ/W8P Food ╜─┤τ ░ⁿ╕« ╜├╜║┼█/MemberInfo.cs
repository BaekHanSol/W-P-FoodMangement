﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace W8P_Food_식당_관리_시스템
{
    public class MemberInfo
    {
        public int MemberId;
        public string MemberName;
        public string PhoneNum;
        public DateTime Birthdate;
        public string address;
        public int Point;
        public string Grade;
    }
}
