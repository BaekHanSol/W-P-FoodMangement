﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using MySql.Data.Common;

namespace W8P_Food_식당_관리_시스템
{
    public partial class DUI6009 : Form // 발주처 수정
    {
        private MySqlConnection connection;
        private MySqlDataAdapter mySqlDataAdapter;
        DUI6008 dui6008;

        public DUI6009(DUI6008 f)
        {
            dui6008 = f;
            InitializeComponent();
        }

        private bool OpenConnection()
        {
            try
            {
                connection.Open();
                return true;
            }
            catch (MySqlException ex)
            {
                switch (ex.Number)
                {
                    case 0:
                        MessageBox.Show("Cannot connect to server. Contact administrator");
                        break;
                    case 1045:
                        MessageBox.Show("Invalid username/password, please try again");
                        break;
                    default:
                        MessageBox.Show(ex.Message);
                        break;
                }
                return false;
            }
        }

        private bool CloseConnection()
        {
            try
            {
                connection.Close();
                return true;
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message);
                return false;
            }
        }

        private void btnRegister_Click(object sender, EventArgs e)
        {
            if (txtName.Text == null || txtPhone.Text == null || txtAddress.Text == "" || txtSerial.Text == ""
                || txtCharger.Text == "" || txtPhone.Text == "")
            {
                MessageBox.Show("데이터를 모두 입력하세요.");
                return;
            }

            string strConn = "Server=218.233.209.73;Port=10040;Database=w8p_foodmanagement_system;Uid=root;Pwd=scotish1;pooling = false; convert zero datetime=True";
            connection = new MySqlConnection(strConn);

            if (this.OpenConnection() == true)
            {
                ProviderInfo pi = new ProviderInfo();
                pi = dui6008.getPInfo();

                pi.phone = txtNum.Text;
                pi.address = txtAddress.Text;
                pi.registrationNum = txtSerial.Text;
                pi.chargerName = txtCharger.Text;
                pi.chargerNum = txtPhone.Text;
                pi.constractDate = dateTimePicker1.Value;
                pi.expirationDate = dateTimePicker2.Value;

                // 쿼리문 작성
                string query = "UPDATE provider SET phone=@phone, address=@address, registrationNum=@registrationNum, chargerName=@chargerName, chargerNum=@chargerNum, constractDate=@constractDate, expirationDate=@expirationDate WHERE name=@name";
                MySqlCommand cmd = new MySqlCommand(query, connection);

                cmd.Parameters.AddWithValue("@name", pi.name);
                cmd.Parameters.AddWithValue("@phone", pi.phone);
                cmd.Parameters.AddWithValue("@address", pi.address);
                cmd.Parameters.AddWithValue("@registrationNum", pi.registrationNum);
                cmd.Parameters.AddWithValue("@chargerName", pi.chargerName);
                cmd.Parameters.AddWithValue("@chargerNum", pi.chargerNum);
                cmd.Parameters.AddWithValue("@constractDate", pi.constractDate);
                cmd.Parameters.AddWithValue("@expirationDate", pi.expirationDate);
                cmd.ExecuteNonQuery();
                this.CloseConnection();

                this.Dispose();
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            dui6008.dui6009 = null;
            this.Dispose();
        }

        private void DUI6009_Load(object sender, EventArgs e)
        {
            string strConn = "Server=218.233.209.73;Port=10040;Database=w8p_foodmanagement_system;Uid=root;Pwd=scotish1;pooling = false; convert zero datetime=True";
            connection = new MySqlConnection(strConn);

            if (this.OpenConnection() == true)
            {
                ProviderInfo pi = new ProviderInfo();
                pi = dui6008.getPInfo();

                txtName.Text = pi.name;
            }
        }
    }
}
