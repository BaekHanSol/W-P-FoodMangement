﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using MySql.Data.Common;


namespace W8P_Food_식당_관리_시스템
{
    public partial class DUI3003 : Form
    {
        DUI3002 dui3002;
        private MySqlConnection connection;
        private MySqlDataAdapter mySqlDataAdapter;

        public DUI3003(DUI3002 f)
        {
            dui3002 = f;
            InitializeComponent();
        }

        private void DUI3003_Load(object sender, EventArgs e)
        {

        }

        private bool OpenConnection()
        {
            try
            {
                connection.Open();
                return true;
            }
            catch (MySqlException ex)
            {
                switch (ex.Number)
                {
                    case 0:
                        MessageBox.Show("Cannot connect to server. Contact administrator");
                        break;
                    case 1045:
                        MessageBox.Show("Invalid username/password, please try again");
                        break;
                    default:
                        MessageBox.Show(ex.Message);
                        break;
                }
                return false;
            }
        }

        private bool CloseConnection()
        {
            try
            {
                connection.Close();
                return true;
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message);
                return false;
            }
        }
        private bool formatCheck()
        {
            decimal num = 0;
            string amount = calorieTxt.Text;
            string cookTime = cookTimeTxt.Text;
            string price = priceTxt.Text;

            bool isFormatOk1 = decimal.TryParse(amount, out num);
            bool isFormatOk2 = decimal.TryParse(cookTime, out num);
            bool isFormatOk3 = decimal.TryParse(price, out num);


            if (isFormatOk1 == false || isFormatOk2 == false || isFormatOk3 == false)
            {
                MessageBox.Show("[오류] 형식이 일치하지 않습니다.");
                return false;
            }

            return true;
        }
        // 수정
        private void button1_Click(object sender, EventArgs e)
        {
            // 유효성
            if (!formatCheck())
                return;

            if (calorieTxt.Text == "" || cookTimeTxt.Text == "" || menuTxt.Text == "" || priceTxt.Text == "")
            {
                MessageBox.Show("데이터를 모두 입력하세요.");
                return;
            }
            if (menuTxt.TextLength > 10)
            {
                MessageBox.Show("메뉴명의 길이는 10자리 이내로 입력해주세요.");
                return;
            }

            if (priceTxt.TextLength > 11)
            {
                MessageBox.Show("가격의 길이는 11자리 이내로 입력해주세요.");
                return;
            }

            if (calorieTxt.TextLength > 11)
            {
                MessageBox.Show("칼로리의 길이는 11자리 이내로 입력해주세요.");
                return;
            }

            if (cookTimeTxt.TextLength > 11)
            {
                MessageBox.Show("조리시간의 길이는 11자리 이내로 입력해주세요.");
                return;
            }


            string strConn = "Server=218.233.209.73;Port=10040;Database=w8p_foodmanagement_system;Uid=root;Pwd=scotish1;pooling = false; convert zero datetime=True";
            connection = new MySqlConnection(strConn);

            // 발주처 등록
            if (this.OpenConnection() == true)
            {
                MenuInfo mi = new MenuInfo();
                mi = dui3002.getMenuInfo();

                mi.menuName = menuTxt.Text;
                mi.price = Convert.ToInt32(priceTxt.Text);
                mi.calorie = Convert.ToInt32(calorieTxt.Text);
                mi.cookTime = Convert.ToInt32(cookTimeTxt.Text);
                mi.registration = dateTimePicker1.Value;
                mi.aboitionDate = dateTimePicker2.Value;

                // 쿼리문 작성
                string query = "UPDATE menu SET name=@name, price=@price, calorie=@calorie, cookTime=@cookTime, registrationDate=@registrationDate, aboitionDate=@aboitionDate WHERE id=@id";
                MySqlCommand cmd = new MySqlCommand(query, connection);

                cmd.Parameters.AddWithValue("@id", mi.menuId);
                cmd.Parameters.AddWithValue("@name", mi.menuName);
                cmd.Parameters.AddWithValue("@price", mi.price);
                cmd.Parameters.AddWithValue("@calorie", mi.calorie);
                cmd.Parameters.AddWithValue("@cookTime", mi.cookTime);
                cmd.Parameters.AddWithValue("@registrationDate", mi.registration);
                cmd.Parameters.AddWithValue("@aboitionDate", mi.aboitionDate);
                cmd.ExecuteNonQuery();
                this.CloseConnection();

                this.Dispose();
            }

            dui3002.dui3003 = null;
        }

        // 닫기
        private void button2_Click(object sender, EventArgs e)
        {
            dui3002.dui3003 = null;
            this.Dispose();
        }
    }
}
