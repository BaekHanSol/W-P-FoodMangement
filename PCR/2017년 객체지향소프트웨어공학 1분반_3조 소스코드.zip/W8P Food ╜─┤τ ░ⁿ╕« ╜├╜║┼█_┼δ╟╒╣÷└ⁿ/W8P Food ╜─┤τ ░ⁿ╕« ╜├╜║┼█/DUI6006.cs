﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using MySql.Data.Common;

namespace W8P_Food_식당_관리_시스템
{
    public partial class DUI6006 : Form // 발주 반품 정보 수정
    {
        private MySqlConnection connection;
        private MySqlDataAdapter mySqlDataAdapter;
        DUI6005 dui6005;

        public DUI6006(DUI6005 f)
        {
            dui6005 = f;
            InitializeComponent();
        }

        private bool OpenConnection()
        {
            try
            {
                connection.Open();
                return true;
            }
            catch (MySqlException ex)
            {
                switch (ex.Number)
                {
                    case 0:
                        MessageBox.Show("Cannot connect to server. Contact administrator");
                        break;
                    case 1045:
                        MessageBox.Show("Invalid username/password, please try again");
                        break;
                    default:
                        MessageBox.Show(ex.Message);
                        break;
                }
                return false;
            }
        }

        private bool CloseConnection()
        {
            try
            {
                connection.Close();
                return true;
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message);
                return false;
            }
        }

        private bool formatCheck()
        {
            decimal num = 0;
            string price = txtPrice.Text;
            bool isFormatOk2 = decimal.TryParse(price, out num);

            if (isFormatOk2 == false)
            {
                MessageBox.Show("[오류] 형식이 일치하지 않습니다.");
                return false;
            }

            return true;
        }

        private void OK_Click(object sender, EventArgs e)
        {
            if (!formatCheck())
                return;

            if (comboProvider.SelectedItem == null || comboType.SelectedItem == null || txtPrice.Text == "")
            {
                MessageBox.Show("데이터를 모두 입력하세요.");
                return;
            }

            string strConn = "Server=218.233.209.73;Port=10040;Database=w8p_foodmanagement_system;Uid=root;Pwd=scotish1;pooling = false; convert zero datetime=True";
            connection = new MySqlConnection(strConn);

            if (this.OpenConnection() == true)
            {
                OrderReturnInfo or = new OrderReturnInfo();
                or = dui6005.getORInfo();

                or.provider = comboProvider.SelectedItem.ToString();
                or.type = comboType.SelectedItem.ToString();
                or.date = dateTimePicker1.Value;
                or.price = Convert.ToInt32(txtPrice.Text);

                // 쿼리문 작성
                string query = "UPDATE orderreturn SET type=@type, provider=@provider, date=@date, price=@price WHERE id=@id";
                MySqlCommand cmd = new MySqlCommand(query, connection);

                cmd.Parameters.AddWithValue("@id", or.id);
                cmd.Parameters.AddWithValue("@type", or.type);
                cmd.Parameters.AddWithValue("@provider", or.provider);
                cmd.Parameters.AddWithValue("@date", or.date);
                cmd.Parameters.AddWithValue("@price", or.price);
                cmd.ExecuteNonQuery();
                this.CloseConnection();

                dui6005.dui6006 = null;
                this.Dispose();
            }
        }

        private void CANCEL_Click(object sender, EventArgs e)
        {
            dui6005.dui6006 = null;
            this.Dispose();
        }

        private void DUI6006_Load(object sender, EventArgs e)
        {
            string strConn = "Server=218.233.209.73;Port=10040;Database=w8p_foodmanagement_system;Uid=root;Pwd=scotish1;pooling = false; convert zero datetime=True";
            connection = new MySqlConnection(strConn);

            if (this.OpenConnection() == true)
            {
                DataTable DTProvider;

                // 발주처 등록
                mySqlDataAdapter = new MySqlDataAdapter("select name from provider", connection);
                DTProvider = new DataTable();
                mySqlDataAdapter.Fill(DTProvider);

                for (int i = 0; i < DTProvider.Rows.Count; i++)
                {
                    DataRow dr = DTProvider.Rows[i];
                    comboProvider.Items.Add(dr["name"].ToString());
                }

                this.CloseConnection();
            }
        }
    }
}
