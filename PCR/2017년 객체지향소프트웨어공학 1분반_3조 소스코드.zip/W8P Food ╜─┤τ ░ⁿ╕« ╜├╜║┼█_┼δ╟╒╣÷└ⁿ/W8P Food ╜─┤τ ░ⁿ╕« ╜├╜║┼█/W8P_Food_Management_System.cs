﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace W8P_Food_식당_관리_시스템
{
    public partial class W8P_Food_Management_System : Form
    {
        public static int MAX_BUTTON = 20;  //만들수 있는 버튼의 최대 갯수
        public int count = 0;               //만들어진 버튼의 수
        public Button[] newBtn = new Button[MAX_BUTTON];
        MdiClient mdi = null;

        // 기초 자료 관리
        public DUI1001 dui1001 = null; // 영업일 등록
        public DUI1002 dui1002 = null; // 영업일 조회
        public DUI1003 dui1003 = null; // 영업일 수정
        public DUI1005 dui1005 = null; // 포인트 적립률 등록
        public DUI1006 dui1006 = null; // 포인트 적립률 조회
        public DUI1007 dui1007 = null; // 포인트 적립률 수정

        // 주문 정보 관리
        public DUI2001 dui2001 = null; // 등록
        public DUI2002 dui2002 = null; // 조회
        public DUI2003 dui2003 = null; // 수정

        // 식단 관리
        public DUI3001 dui3001 = null; // 등록
        public DUI3002 dui3002 = null; // 조회
        public DUI3003 dui3003 = null; // 수정

        // 식자재 관리
        public DUI4001 dui4001 = null; // 등록
        public DUI4002 dui4002 = null; // 조회
        public DUI4003 dui4003 = null; // 수정

        // 식자재 입출고 관리
        public DUI5001 dui5001 = null; // 입출고 등록
        public DUI5002 dui5002 = null; // 입출고 조회
        public DUI5003 dui5003 = null; // 입출고 수정
        public DUI5004 dui5004 = null; // 폐기 등록
        public DUI5005 dui5005 = null; // 폐기 조회
        public DUI5006 dui5006 = null; // 폐기 수정

        // 식자재 발주 반품 관리
        public DUI6001 dui6001 = null; // 예상 판매량 산출
        public DUI6002 dui6002 = null; // 식자재 소요량 산출
        public DUI6003 dui6003 = null; // 식자재 발주량 결정
        public DUI6004 dui6004 = null; // 등록
        public DUI6005 dui6005 = null; // 조회
        public DUI6005_2 dui6005_2 = null; // 상세조회
        public DUI6006 dui6006 = null; // 수정

        // 발주처 관리
        public DUI6007 dui6007 = null; // 등록
        public DUI6008 dui6008 = null; // 조회
        public DUI6009 dui6009 = null; // 수정

        // 매출 관리
        public DUI7001 dui7001 = null; // 현재 주문 조회
        public DUI7002 dui7002 = null; // 매출 실적 조회

        // 회원 관리
        public DUI8001 dui8001 = null; // 등록
        public DUI8002 dui8002 = null; // 조회
        public DUI8003 dui8003 = null; // 수정

        // 예약 관리
        public DUI9001 dui9001 = null; // 등록
        public DUI9002 dui9002 = null; // 조회
        public DUI9003 dui9003 = null; // 수정

        public W8P_Food_Management_System()
        {
            InitializeComponent();

            foreach (Control ctl in this.Controls)  //MdiContainer의 색상을 변경
            {
                try
                {
                    mdi = (MdiClient)ctl;
                    mdi.BackColor = this.BackColor;
                }
                catch (InvalidCastException e)
                {
                }
            }
        }

        private void treeView1_NodeMouseClick(object sender, TreeNodeMouseClickEventArgs e)
        {
            
        }

        private void treeView1_AfterSelect(object sender, TreeViewEventArgs e)
        {
            Form form = null;
            panel1.Controls.Clear();

            if (treeView1.SelectedNode.Level == 2 && count >= MAX_BUTTON)
            {
                MessageBox.Show("열린 창이 너무 많습니다.");
            }

            // -------------------------<기초 자료 관리>------------------------

            else if (treeView1.SelectedNode.Name == "uc1001") // 영업일 등록
            {
                if (dui1001 == null)
                {
                    dui1001 = new DUI1001(this);
                    dui1001.TopLevel = false;
                    dui1001.Dock = System.Windows.Forms.DockStyle.Fill;
                }

                form = dui1001;
                form.FormBorderStyle = FormBorderStyle.None;
                panel1.Controls.Add(form);
                form.Show();
            }

            else if (treeView1.SelectedNode.Name == "uc1004") // 영업일 조회
            {
                if (dui1002 == null)
                {
                    dui1002 = new DUI1002(this);
                    dui1002.TopLevel = false;
                    dui1002.Dock = System.Windows.Forms.DockStyle.Fill;
                }

                form = dui1002;
                form.FormBorderStyle = FormBorderStyle.None;
                panel1.Controls.Add(form);
                form.Show();
            }

            else if (treeView1.SelectedNode.Name == "uc1005") // 포인트 적립률 등록
            {
                if (dui1005 == null)
                {
                    dui1005 = new DUI1005(this);
                    dui1005.TopLevel = false;
                    dui1005.Dock = System.Windows.Forms.DockStyle.Fill;
                }

                form = dui1005;
                form.FormBorderStyle = FormBorderStyle.None;
                panel1.Controls.Add(form);
                form.Show();
            }
            else if (treeView1.SelectedNode.Name == "uc1008") // 포인트 적립률 조회
            {
                if (dui1006 == null)
                {
                    dui1006 = new DUI1006(this);
                    dui1006.TopLevel = false;
                    dui1006.Dock = System.Windows.Forms.DockStyle.Fill;
                }

                form = dui1006;
                form.FormBorderStyle = FormBorderStyle.None;
                panel1.Controls.Add(form);
                form.Show();
            }
            /*
            // -----------------------<주문 정보 관리>----------------------

            else if (treeView1.SelectedNode.Name == "uc2001") // 주문 정보 등록
            {
                if (dui2001 == null)
                {
                    dui2001 = new DUI2001();
                    dui2001.TopLevel = false;
                    dui2001.Dock = System.Windows.Forms.DockStyle.Fill;
                }

                form = dui2001;
                //form.FormBorderStyle = FormBorderStyle.None;
                panel1.Controls.Add(form);
                form.Show();
            }
            else if (treeView1.SelectedNode.Name == "uc2004") // 주문 정보 조회
            {
                if (dui2002 == null)
                {
                    dui2002 = new DUI2002();
                    dui2002.TopLevel = false;
                    dui2002.Dock = System.Windows.Forms.DockStyle.Fill;
                }

                form = dui2002;
                //form.FormBorderStyle = FormBorderStyle.None;
                panel1.Controls.Add(form);
                form.Show();
            }
            */

            // ----------------------------<식단 관리>-----------------------
            
            else if (treeView1.SelectedNode.Name == "uc3001") // 식단 등록
            {
                if (dui3001 == null)
                {
                    dui3001 = new DUI3001(this);
                    dui3001.TopLevel = false;
                    dui3001.Dock = System.Windows.Forms.DockStyle.Fill;
                }

                form = dui3001;
                form.FormBorderStyle = FormBorderStyle.None;
                panel1.Controls.Add(form);
                form.Show();
            }
            else if (treeView1.SelectedNode.Name == "uc3004") // 식단 조회
            {
                if (dui3002 == null)
                {
                    dui3002 = new DUI3002(this);
                    dui3002.TopLevel = false;
                    dui3002.Dock = System.Windows.Forms.DockStyle.Fill;
                }

                form = dui3002;
                form.FormBorderStyle = FormBorderStyle.None;
                panel1.Controls.Add(form);
                form.Show();
            }

            // --------------------------<식자재 관리>----------------------

            else if (treeView1.SelectedNode.Name == "uc4001") // 식자재 등록
            {
                if (dui4001 == null)
                {
                    dui4001 = new DUI4001(this);
                    dui4001.TopLevel = false;
                    dui4001.Dock = System.Windows.Forms.DockStyle.Fill;
                }

                form = dui4001;
                form.FormBorderStyle = FormBorderStyle.None;
                panel1.Controls.Add(form);
                form.Show();
            }
            else if (treeView1.SelectedNode.Name == "uc4004") // 식자재 조회
            {
                if (dui4002 == null)
                {
                    dui4002 = new DUI4002(this);
                    dui4002.TopLevel = false;
                    dui4002.Dock = System.Windows.Forms.DockStyle.Fill;
                }

                form = dui4002;
                form.FormBorderStyle = FormBorderStyle.None;
                panel1.Controls.Add(form);
                form.Show();
            }

            // ----------------------<입출고 관리>--------------

            else if (treeView1.SelectedNode.Name == "uc5001") // 입출고 등록
            {
                if (dui5001 == null)
                {
                    dui5001 = new DUI5001(this);
                    dui5001.TopLevel = false;
                    dui5001.Dock = System.Windows.Forms.DockStyle.Fill;
                }

                form = dui5001;
                form.FormBorderStyle = FormBorderStyle.None;
                panel1.Controls.Add(form);
                form.Show();
            }

            else if (treeView1.SelectedNode.Name == "uc5004") // 입출고 조회
            {
                if (dui5002 == null)
                {
                    dui5002 = new DUI5002(this);
                    dui5002.TopLevel = false;
                    dui5002.Dock = System.Windows.Forms.DockStyle.Fill;
                }

                form = dui5002;
                form.FormBorderStyle = FormBorderStyle.None;
                panel1.Controls.Add(form);
                form.Show();
            }

            else if (treeView1.SelectedNode.Name == "uc5009") // 폐기 등록
            {
                if (dui5004 == null)
                {
                    dui5004 = new DUI5004(this);
                    dui5004.TopLevel = false;
                    dui5004.Dock = System.Windows.Forms.DockStyle.Fill;
                }

                form = dui5004;
                form.FormBorderStyle = FormBorderStyle.None;
                panel1.Controls.Add(form);
                form.Show();
            }

            else if (treeView1.SelectedNode.Name == "uc5012") // 폐기 조회
            {
                if (dui5005 == null)
                {
                    dui5005 = new DUI5005(this);
                    dui5005.TopLevel = false;
                    dui5005.Dock = System.Windows.Forms.DockStyle.Fill;
                }

                form = dui5005;
                form.FormBorderStyle = FormBorderStyle.None;
                panel1.Controls.Add(form);
                form.Show();
            }

            // ----------------------<발주 반품 정보 관리>---------------------

            else if (treeView1.SelectedNode.Name == "uc6004") // 발주 반품 정보 등록
            {
                if (dui6004 == null)
                {
                    dui6004 = new DUI6004(this);
                    dui6004.TopLevel = false;
                    dui6004.Dock = System.Windows.Forms.DockStyle.Fill;
                }

                form = dui6004;
                form.FormBorderStyle = FormBorderStyle.None;
                panel1.Controls.Add(form);
                form.Show();
            }
            else if (treeView1.SelectedNode.Name == "uc6007") // 발주 반품 정보 조회
            {
                if (dui6005 == null)
                {
                    dui6005 = new DUI6005(this);
                    dui6005.TopLevel = false;
                    dui6005.Dock = System.Windows.Forms.DockStyle.Top;
                }

                form = dui6005;
                form.FormBorderStyle = FormBorderStyle.None;
                panel1.Controls.Add(form);
                form.Show();
            }

            // ----------------------------<발주처 관리>-------------------------

            else if (treeView1.SelectedNode.Name == "uc6008") // 발주처 등록
            {
                if (dui6007 == null)
                {
                    dui6007 = new DUI6007(this);
                    dui6007.TopLevel = false;
                    dui6007.Dock = System.Windows.Forms.DockStyle.Fill;
                }

                form = dui6007;
                form.FormBorderStyle = FormBorderStyle.None;
                panel1.Controls.Add(form);
                form.Show();
            }
            else if (treeView1.SelectedNode.Name == "uc6011") // 발주처 조회
            {
                if (dui6008 == null)
                {
                    dui6008 = new DUI6008(this);
                    dui6008.TopLevel = false;
                    dui6008.Dock = System.Windows.Forms.DockStyle.Fill;
                }

                form = dui6008;
                form.FormBorderStyle = FormBorderStyle.None;
                panel1.Controls.Add(form);
                form.Show();
            }

            // ------------------------------<매출관리>--------------------------------

            else if (treeView1.SelectedNode.Name == "uc7001") // 현재 주문 조회
            {
                if (dui7001 == null)
                {
                    dui7001 = new DUI7001(this);
                    dui7001.TopLevel = false;
                    dui7001.Dock = System.Windows.Forms.DockStyle.Fill;
                }

                form = dui7001;
                form.FormBorderStyle = FormBorderStyle.None;
                panel1.Controls.Add(form);
                form.Show();
            }
            else if (treeView1.SelectedNode.Name == "uc7004") // 매출 실적 조회
            {
                if (dui7002 == null)
                {
                    dui7002 = new DUI7002(this);
                    dui7002.TopLevel = false;
                    dui7002.Dock = System.Windows.Forms.DockStyle.Fill;
                }

                form = dui7002;
                form.FormBorderStyle = FormBorderStyle.None;
                panel1.Controls.Add(form);
                form.Show();
            }

            // ----------------------<회원 관리>----------------------

            else if (treeView1.SelectedNode.Name == "uc8001") // 회원 등록
            {
                if (dui8001 == null)
                {
                    dui8001 = new DUI8001(this);
                    dui8001.TopLevel = false;
                    dui8001.Dock = System.Windows.Forms.DockStyle.Fill;
                }

                form = dui8001;
                form.FormBorderStyle = FormBorderStyle.None;
                panel1.Controls.Add(form);
                form.Show();
            }
            else if (treeView1.SelectedNode.Name == "uc8004") // 회원 조회
            {
                if (dui8002 == null)
                {
                    dui8002 = new DUI8002(this);
                    dui8002.TopLevel = false;
                    dui8002.Dock = System.Windows.Forms.DockStyle.Fill;
                }

                form = dui8002;
                form.FormBorderStyle = FormBorderStyle.None;
                panel1.Controls.Add(form);
                form.Show();
            }

            // -----------------------------<예약 관리>------------------------

            else if (treeView1.SelectedNode.Name == "uc9001") // 예약 등록
            {
                if (dui9001 == null)
                {
                    dui9001 = new DUI9001(this);
                    dui9001.TopLevel = false;
                    dui9001.Dock = System.Windows.Forms.DockStyle.Fill;
                }

                form = dui9001;
                form.FormBorderStyle = FormBorderStyle.None;
                panel1.Controls.Add(form);
                form.Show();
            }
            else if (treeView1.SelectedNode.Name == "uc9004") // 예약 조회
            {
                if (dui9002 == null)
                {
                    dui9002 = new DUI9002(this);
                    dui9002.TopLevel = false;
                    dui9002.Dock = System.Windows.Forms.DockStyle.Fill;
                }

                form = dui9002;
                form.FormBorderStyle = FormBorderStyle.None;
                panel1.Controls.Add(form);
                form.Show();
            }

            // -------------------------------<각종 산출>---------------------

            else if (treeView1.SelectedNode.Name == "uc6001") // 예상 판매량 산출
            {
                if (dui6001 == null)
                {
                    dui6001 = new DUI6001();
                    dui6001.TopLevel = false;
                    dui6001.Dock = System.Windows.Forms.DockStyle.Fill;
                }

                form = dui6001;
                form.FormBorderStyle = FormBorderStyle.None;
                panel1.Controls.Add(form);
                form.Show();
            }
            
                else if (treeView1.SelectedNode.Name == "uc6002") // 식자재 소요량 산출
            {
                if (dui6002 == null)
                {
                    dui6002 = new DUI6002();
                    dui6002.TopLevel = false;
                    dui6002.Dock = System.Windows.Forms.DockStyle.Fill;
                }

                form = dui6002;
                form.FormBorderStyle = FormBorderStyle.None;
                panel1.Controls.Add(form);
                form.Show();
            }
            else if (treeView1.SelectedNode.Name == "uc6003") // 식자재 발주량 결정
            {
                if (dui6003 == null)
                {
                    dui6003 = new DUI6003();
                    dui6003.TopLevel = false;
                    dui6003.Dock = System.Windows.Forms.DockStyle.Fill;
                }

                form = dui6003;
                form.FormBorderStyle = FormBorderStyle.None;
                panel1.Controls.Add(form);
                form.Show();
            }
        }
    }
}
