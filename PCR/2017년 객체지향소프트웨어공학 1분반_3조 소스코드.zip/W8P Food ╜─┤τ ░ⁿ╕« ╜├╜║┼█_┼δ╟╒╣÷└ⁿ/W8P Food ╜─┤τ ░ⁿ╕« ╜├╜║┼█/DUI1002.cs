using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using MySql.Data.Common;

namespace W8P_Food_�Ĵ�_����_�ý���
{
    public partial class DUI1002 : Form
    {
        private MySqlConnection connection;
        private MySqlDataAdapter mySqlDataAdapter;
        W8P_Food_Management_System mainform;
        public DUI1003 dui1003;

    public DUI1002(W8P_Food_Management_System f)
    {
        mainform = f;    
        InitializeComponent();
    }

        private void dataGridView1_RowValidated(object sender, DataGridViewCellEventArgs e)
        {
            DataTable changes = ((DataTable)dataGridView1.DataSource).GetChanges();

            if (changes != null)
            {
                MySqlCommandBuilder mcb = new MySqlCommandBuilder(mySqlDataAdapter);
                mySqlDataAdapter.UpdateCommand = mcb.GetUpdateCommand();
                mySqlDataAdapter.Update(changes);
                ((DataTable)dataGridView1.DataSource).AcceptChanges();
            }
        }

        private bool OpenConnection()
        {
            try
            {
                connection.Open();
                return true;
                }
                catch (MySqlException ex)
                {
                    switch (ex.Number)
                    {
                        case 0:
                            MessageBox.Show("Cannot connect to server. Contact administrator");
                            break;
                        case 1045:
                            MessageBox.Show("Invalid username/password, please try again");
                            break;
                        default:
                            MessageBox.Show(ex.Message);
                            break;
                    }
                    return false;
                }
            }

        private bool CloseConnection()
            {
                try
                {
                    connection.Close();
                    return true;
                }
                catch (MySqlException ex)
                {
                    MessageBox.Show(ex.Message);
                    return false;
                }
            }

        private void DUI1002_Load(object sender, EventArgs e)
        {
            resetDataSheet();
        }

        private void resetDataSheet()
        {
            string strConn = "Server=218.233.209.73;Port=10040;Database=w8p_foodmanagement_system;Uid=root;Pwd=scotish1;pooling = false; convert zero datetime=True";
            connection = new MySqlConnection(strConn);

            if (this.OpenConnection() == true)
            {
                mySqlDataAdapter = new MySqlDataAdapter("select * from businessday", connection);
                DataSet DS = new DataSet();
                mySqlDataAdapter.Fill(DS);
                dataGridView1.DataSource = DS.Tables[0];
                this.CloseConnection();
            }
        }

        //������ ���� -> form dui1003���� �̵�
        private void button1_Click(object sender, EventArgs e)
        {
            if (dui1003 == null)
            {
                dui1003 = new DUI1003(this);
            }

            dui1003.ShowDialog();
            resetDataSheet();
        }

        //������ ����
        private void button2_Click(object sender, EventArgs e)
        {
            string strConn = "Server=218.233.209.73;Port=10040;Database=w8p_foodmanagement_system;Uid=root;Pwd=scotish1;pooling = false; convert zero datetime=True";
            connection = new MySqlConnection(strConn);

            if (this.OpenConnection() == true)
            {
                BusinessDayInfo bi = new BusinessDayInfo();
                bi = getBusinessDayInfo();

                // ������ �ۼ�
                string query = "DELETE from businessday WHERE id=@id";
                MySqlCommand cmd = new MySqlCommand(query, connection);

                cmd.Parameters.AddWithValue("@id", bi.id);
                cmd.ExecuteNonQuery();
                this.CloseConnection();

                resetDataSheet();
                MessageBox.Show("�񿵾��� : " + bi.nonBusinessDay + "\n���� �Ϸ�");
                return;
            }
        }

        //��������ȸ ȭ�� �ݱ�
        private void button3_Click(object sender, EventArgs e)
        {
            mainform.dui1002 = null;
            this.Dispose();
        }

        public BusinessDayInfo getBusinessDayInfo()
        {
            BusinessDayInfo bi = new BusinessDayInfo();

            bi.id = Convert.ToInt32(dataGridView1.Rows[dataGridView1.CurrentCellAddress.Y].Cells[0].Value);
            bi.nonBusinessDay = (DateTime)dataGridView1.Rows[dataGridView1.CurrentCellAddress.Y].Cells[1].Value;

            return bi;
        }
        
    }
}
