﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using MySql.Data.Common;

namespace W8P_Food_식당_관리_시스템
{
    public partial class DUI5004 : Form
    {
        private MySqlConnection connection;
        private MySqlDataAdapter mySqlDataAdapter;
        W8P_Food_Management_System mainform;

        public DUI5004(W8P_Food_Management_System f)
        {
            mainform = f;
            InitializeComponent();
        }

        private bool OpenConnection()
        {
            try
            {
                connection.Open();
                return true;
            }
            catch (MySqlException ex)
            {
                switch (ex.Number)
                {
                    case 0:
                        MessageBox.Show("Cannot connect to server. Contact administrator");
                        break;
                    case 1045:
                        MessageBox.Show("Invalid username/password, please try again");
                        break;
                    default:
                        MessageBox.Show(ex.Message);
                        break;
                }
                return false;
            }
        }

        private bool CloseConnection()
        {
            try
            {
                connection.Close();
                return true;
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message);
                return false;
            }
        }

        private void DUI5004_Load(object sender, EventArgs e)
        {
            string strConn = "Server=218.233.209.73;Port=10040;Database=w8p_foodmanagement_system;Uid=root;Pwd=scotish1;pooling = false; convert zero datetime=True";
            connection = new MySqlConnection(strConn);

            if (this.OpenConnection() == true)
            {
                DataTable DTProvider;
                DataTable DTIngredient;

                //mySqlDataAdapter = new MySqlDataAdapter("select name from provider", connection);
                //DTProvider = new DataTable();
                //mySqlDataAdapter.Fill(DTProvider);

                //for (int i = 0; i < DTProvider.Rows.Count; i++)
                //{
                //    DataRow dr = DTProvider.Rows[i];
                //    comboBox1.Items.Add(dr["name"].ToString());
                //}

                // 식재료 등록
                mySqlDataAdapter = new MySqlDataAdapter("select * from material", connection);
                DTIngredient = new DataTable();
                mySqlDataAdapter.Fill(DTIngredient);

                for (int i = 0; i < DTIngredient.Rows.Count; i++)
                {
                    DataRow dr = DTIngredient.Rows[i];
                    comboBox1.Items.Add(dr["name"].ToString());
                }

                this.CloseConnection();


            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void btn_regist_Click(object sender, EventArgs e)
        {
            if (comboBox1.SelectedItem == null || textBox3.Text == "" || textBox2.Text == "")
            {
                MessageBox.Show("[오류] 필수 정보가 입력되지 않았습니다.");
                return;
            }
            decimal num = 0;

            string q = textBox2.Text;

            bool isFormatOk1 = decimal.TryParse(q, out num);



            if (isFormatOk1 == false)
            {
                MessageBox.Show("[오류] 형식이 일치하지 않습니다.");
                return;
            }


            if (comboBox1.SelectionLength > 20)
            {
                MessageBox.Show("폐기 항목의 길이는 20 자리 이하로 입력해주세요.");
                return;
            }

            if (textBox2.TextLength > 20)
            {
                MessageBox.Show("폐기량의 길이는 10 자리 이하로 입력해주세요.");
                return;
            }

            if (textBox3.TextLength > 20)
            {
                MessageBox.Show("폐기사유의 길이는310 자리 이하로 입력해주세요.");
                return;
            }


            string strConn = "Server=218.233.209.73;Port=10040;Database=w8p_foodmanagement_system;Uid=root;Pwd=scotish1;pooling = false; convert zero datetime=True";
            connection = new MySqlConnection(strConn);


            if (this.OpenConnection() == true)
            {
                IngredientsDisuse or = new IngredientsDisuse();

                or.ingredientsName = comboBox1.SelectedItem.ToString();
                or.quantity = Convert.ToInt32(textBox2.Text);
                or.Date = (DateTime)(dateTimePicker1.Value);
                or.reason = textBox3.Text;

                ///////////////////////// 경고 : 테이블에 첫 튜플 존재 X시 오류남!!!(cause: id++이 없으므로)//////////////////////

                string query3 = "select amount from material where name=@name";
                MySqlCommand cmd3 = new MySqlCommand(query3, connection);

                cmd3.Parameters.AddWithValue("@name", or.ingredientsName);
                cmd3.Parameters.AddWithValue("@amount", or.quantity);
                cmd3.ExecuteNonQuery();
                MySqlDataReader rdr = cmd3.ExecuteReader();

                int sum = 0;
                while (rdr.Read())
                {
                    string s = rdr["amount"].ToString();
                    sum = Int32.Parse(s);
                    break;
                }


                string Num = textBox2.Text;
                int releaseNum = Convert.ToInt32(Num);
                if (sum < releaseNum)
                {
                    MessageBox.Show("폐기량이 식자재량을 초과하였습니다.");
                    return;
                }

                else if (sum > releaseNum)
                {
                    sum -= Convert.ToInt32(textBox2.Text);
                }



                rdr.Close();


                // 쿼리문 작성
                string query = "INSERT INTO ingredientsdisuse(ingredientsName, quantity, Date, reason)" + "VALUES(@ingredientsName, @quantity, @Date, @reason)";
                MySqlCommand cmd = new MySqlCommand(query, connection);

                cmd.Parameters.AddWithValue("@ingredientsName", or.ingredientsName);
                cmd.Parameters.AddWithValue("@quantity", or.quantity);
                cmd.Parameters.AddWithValue("@Date", or.Date);
                cmd.Parameters.AddWithValue("@reason", or.reason);
                cmd.ExecuteNonQuery();
                MessageBox.Show("등록이 완료 되었습니다.");


                string query2 = "UPDATE material SET name=@name,amount=@amount where name=@name";
                MySqlCommand cmd2 = new MySqlCommand(query2, connection);

                cmd2.Parameters.AddWithValue("@name", or.ingredientsName);
                cmd2.Parameters.AddWithValue("@amount", sum);

                cmd2.ExecuteNonQuery();
                this.CloseConnection();
            }

            mainform.dui5005 = null;
            comboBox1.Text = null;
            textBox2.Text = "";
            textBox3.Text = "";


        }

        private void btn_close_Click(object sender, EventArgs e)
        {
            mainform.dui5004 = null;
            this.Dispose();
        }
    }
}