﻿namespace W8P_Food_식당_관리_시스템
{
    partial class DUI9003
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.Memberid = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.reserveNum = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.Personnum = new System.Windows.Forms.NumericUpDown();
            this.tablenum = new System.Windows.Forms.NumericUpDown();
            this.label5 = new System.Windows.Forms.Label();
            this.date = new System.Windows.Forms.DateTimePicker();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.Personnum)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tablenum)).BeginInit();
            this.SuspendLayout();
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(278, 303);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 41;
            this.button2.Text = "닫기";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(196, 303);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 40;
            this.button1.Text = "수정";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Memberid
            // 
            this.Memberid.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.Memberid.Location = new System.Drawing.Point(141, 106);
            this.Memberid.Name = "Memberid";
            this.Memberid.Size = new System.Drawing.Size(118, 21);
            this.Memberid.TabIndex = 57;
            this.Memberid.Text = "2";
            this.Memberid.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(66, 109);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(57, 12);
            this.label7.TabIndex = 56;
            this.label7.Text = "회원 번호";
            // 
            // reserveNum
            // 
            this.reserveNum.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.reserveNum.Location = new System.Drawing.Point(141, 66);
            this.reserveNum.Name = "reserveNum";
            this.reserveNum.Size = new System.Drawing.Size(118, 21);
            this.reserveNum.TabIndex = 55;
            this.reserveNum.Text = "1";
            this.reserveNum.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(66, 69);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(57, 12);
            this.label6.TabIndex = 54;
            this.label6.Text = "예약 번호";
            // 
            // Personnum
            // 
            this.Personnum.Location = new System.Drawing.Point(141, 234);
            this.Personnum.Name = "Personnum";
            this.Personnum.Size = new System.Drawing.Size(120, 21);
            this.Personnum.TabIndex = 53;
            this.Personnum.Value = new decimal(new int[] {
            4,
            0,
            0,
            0});
            // 
            // tablenum
            // 
            this.tablenum.Location = new System.Drawing.Point(141, 144);
            this.tablenum.Name = "tablenum";
            this.tablenum.Size = new System.Drawing.Size(120, 21);
            this.tablenum.TabIndex = 52;
            this.tablenum.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("맑은 고딕", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label5.Location = new System.Drawing.Point(92, 9);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(234, 45);
            this.label5.TabIndex = 50;
            this.label5.Text = "예약 수정 화면";
            // 
            // date
            // 
            this.date.Location = new System.Drawing.Point(141, 181);
            this.date.Name = "date";
            this.date.Size = new System.Drawing.Size(200, 21);
            this.date.TabIndex = 49;
            this.date.Value = new System.DateTime(2017, 9, 28, 0, 0, 0, 0);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(66, 236);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(69, 12);
            this.label4.TabIndex = 47;
            this.label4.Text = "인원수 정보";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(66, 187);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(57, 12);
            this.label3.TabIndex = 46;
            this.label3.Text = "예약 일시";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(66, 146);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(57, 12);
            this.label2.TabIndex = 45;
            this.label2.Text = "테이블 수";
            // 
            // DUI9003
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(427, 342);
            this.Controls.Add(this.Memberid);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.reserveNum);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.Personnum);
            this.Controls.Add(this.tablenum);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.date);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Name = "DUI9003";
            this.Text = "예약 조회";
            this.Load += new System.EventHandler(this.DUI9003_Load);
            ((System.ComponentModel.ISupportInitialize)(this.Personnum)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tablenum)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox Memberid;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox reserveNum;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.NumericUpDown Personnum;
        private System.Windows.Forms.NumericUpDown tablenum;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.DateTimePicker date;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
    }
}