﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using MySql.Data.Common;

namespace W8P_Food_식당_관리_시스템
{
    public partial class DUI5005 : Form
    {
        private MySqlConnection connection;
        private MySqlDataAdapter mySqlDataAdapter;
        W8P_Food_Management_System mainform;
        public DUI5006 dui5006;
        public int datagrQ=0;

        public DUI5005(W8P_Food_Management_System f)
        {
            mainform = f;
            InitializeComponent();
        }

        private void DUI5005_Load(object sender, EventArgs e)
        {
            resetDataSheet();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            DataTable changes = ((DataTable)dataGridView1.DataSource).GetChanges();

            if (changes != null)
            {
                MySqlCommandBuilder mcb = new MySqlCommandBuilder(mySqlDataAdapter);
                mySqlDataAdapter.UpdateCommand = mcb.GetUpdateCommand();
                mySqlDataAdapter.Update(changes);
                ((DataTable)dataGridView1.DataSource).AcceptChanges();
            }
        }

        private bool OpenConnection()
        {
            try
            {
                connection.Open();
                return true;
            }
            catch (MySqlException ex)
            {
                switch (ex.Number)
                {
                    case 0:
                        MessageBox.Show("Cannot connect to server. Contact administrator");
                        break;
                    case 1045:
                        MessageBox.Show("Invalid username/password, please try again");
                        break;
                    default:
                        MessageBox.Show(ex.Message);
                        break;
                }
                return false;
            }
        }

        private bool CloseConnection()
        {
            try
            {
                connection.Close();
                return true;
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message);
                return false;
            }
        }

        private void resetDataSheet()
        {
            string strConn = "Server=218.233.209.73;Port=10040;Database=w8p_foodmanagement_system;Uid=root;Pwd=scotish1;pooling = false; convert zero datetime=True";
            connection = new MySqlConnection(strConn);

            if (this.OpenConnection() == true)
            {
                mySqlDataAdapter = new MySqlDataAdapter("select * from ingredientsdisuse", connection);
                DataSet DS = new DataSet();
                mySqlDataAdapter.Fill(DS);
                dataGridView1.DataSource = DS.Tables[0];
                this.CloseConnection();
            }
        }

        public IngredientsDisuse getInfo()
        {
            IngredientsDisuse or = new IngredientsDisuse();
            datagrQ = Convert.ToInt32(dataGridView1.Rows[dataGridView1.CurrentCellAddress.Y].Cells[2].Value);

            or.id = Convert.ToInt32(dataGridView1.Rows[dataGridView1.CurrentCellAddress.Y].Cells[0].Value);
            or.ingredientsName = dataGridView1.Rows[dataGridView1.CurrentCellAddress.Y].Cells[1].Value.ToString();
            or.quantity = Convert.ToInt32(dataGridView1.Rows[dataGridView1.CurrentCellAddress.Y].Cells[2].Value);
            or.Date = (DateTime)dataGridView1.Rows[dataGridView1.CurrentCellAddress.Y].Cells[3].Value;
            or.reason = dataGridView1.Rows[dataGridView1.CurrentCellAddress.Y].Cells[4].Value.ToString();
            
            return or;
        }

        private void btn_update_Click(object sender, EventArgs e)
        {
            if (dui5006 == null)
            {
                dui5006 = new DUI5006(this);
            }

            dui5006.ShowDialog();
            resetDataSheet();
        }

        private void btn_delete_Click(object sender, EventArgs e)
        {
            string strConn = "Server=218.233.209.73;Port=10040;Database=w8p_foodmanagement_system;Uid=root;Pwd=scotish1;pooling = false; convert zero datetime=True";
            connection = new MySqlConnection(strConn);

            if (this.OpenConnection() == true)
            {
                IngredientsDisuse or = new IngredientsDisuse();
                or = getInfo();

                // 쿼리문 작성


                string query3 = "select amount from material where name=@name";
                MySqlCommand cmd3 = new MySqlCommand(query3, connection);

                cmd3.Parameters.AddWithValue("@name", or.ingredientsName);
                cmd3.Parameters.AddWithValue("@amount", or.quantity);
                cmd3.ExecuteNonQuery();
                MySqlDataReader rdr = cmd3.ExecuteReader();

                int sum = 0;
                while (rdr.Read())
                {
                    string s = rdr["amount"].ToString();
                    sum = Int32.Parse(s);
                    break;
                }
                rdr.Close();

                string query4 = "select quantity from ingredientsdisuse where id=@id";
                MySqlCommand cmd4 = new MySqlCommand(query4, connection);

                cmd4.Parameters.AddWithValue("@id", or.id);
                cmd4.Parameters.AddWithValue("@quantity", or.quantity);
                cmd4.ExecuteNonQuery();
                MySqlDataReader rdr2 = cmd4.ExecuteReader();

                int n = 0;
                while (rdr2.Read())
                {
                    string s = rdr2["quantity"].ToString();
                    n = Int32.Parse(s);
                    break;
                }

                sum += n;
                rdr2.Close();

                string query = "DELETE from ingredientsdisuse WHERE id=@id";
                MySqlCommand cmd = new MySqlCommand(query, connection);

                cmd.Parameters.AddWithValue("@id", or.id);
                cmd.ExecuteNonQuery();
                MessageBox.Show("삭제되었습니다.");

                string query5 = "UPDATE material SET name=@name,amount=@amount where name=@name";
                MySqlCommand cmd5 = new MySqlCommand(query5, connection);

                cmd5.Parameters.AddWithValue("@name", or.ingredientsName);
                cmd5.Parameters.AddWithValue("@amount", sum);

                cmd5.ExecuteNonQuery();
                this.CloseConnection();

                resetDataSheet();
            }
        }

        private void btn_close_Click(object sender, EventArgs e)
        {
            mainform.dui5005 = null;
            this.Dispose();
        }
    }
}

