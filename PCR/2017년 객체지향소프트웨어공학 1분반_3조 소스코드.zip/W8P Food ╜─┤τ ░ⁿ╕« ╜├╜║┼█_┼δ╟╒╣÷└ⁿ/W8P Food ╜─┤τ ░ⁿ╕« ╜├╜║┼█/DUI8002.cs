﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using MySql.Data.Common;

namespace W8P_Food_식당_관리_시스템
{
    public partial class DUI8002 : Form
    {        
        private MySqlConnection connection;
        private MySqlDataAdapter mySqlDataAdapter;
        W8P_Food_Management_System mainform;
        public DUI8003 dui8003;
        public DUI8002(W8P_Food_Management_System f)
        {
            mainform = f;
            InitializeComponent();
        }
        private bool OpenConnection()
        {
            try
            {
                connection.Open();
                return true;
            }
            catch (MySqlException ex)
            {
                switch (ex.Number)
                {
                    case 0:
                        MessageBox.Show("Cannot connect to server. Contact administrator");
                        break;
                    case 1045:
                        MessageBox.Show("Invalid username/password, please try again");
                        break;
                    default:
                        MessageBox.Show(ex.Message);
                        break;
                }
                return false;
            }
        }

        private bool CloseConnection()
        {
            try
            {
                connection.Close();
                return true;
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message);
                return false;
            }
        }
        public void resetDataSheet()
        {
            string strConn = "Server=218.233.209.73;Port=10040;Database=w8p_foodmanagement_system;Uid=root;Pwd=scotish1;pooling = false; convert zero datetime=True";
            connection = new MySqlConnection(strConn);

            if (this.OpenConnection() == true)
            {
                mySqlDataAdapter = new MySqlDataAdapter("select * from member", connection);
                DataSet DS = new DataSet();
                mySqlDataAdapter.Fill(DS);
                dataGridView1.DataSource = DS.Tables[0];
                this.CloseConnection();
            }
        }
        private void DUI8002_Load(object sender, EventArgs e)
        {
            this.Visible = true;
            resetDataSheet();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            mainform.dui8002 = null;
            this.Visible = false;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string strConn = "Server=218.233.209.73;Port=10040;Database=w8p_foodmanagement_system;Uid=root;Pwd=scotish1;pooling = false; convert zero datetime=True";
            connection = new MySqlConnection(strConn);

            if (this.OpenConnection() == true)
            {
                MemberInfo mi = new MemberInfo();
                mi = getInfo();

                // 쿼리문 작성
                string query = "DELETE from member WHERE id=@id";
                MySqlCommand cmd = new MySqlCommand(query, connection);

                cmd.Parameters.AddWithValue("@id", mi.MemberId);
                cmd.ExecuteNonQuery();
                resetDataSheet();
                this.CloseConnection();               
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (dui8003 == null)
            {
                dui8003 = new DUI8003(this);
            }

            dui8003.ShowDialog();
            resetDataSheet();
        }
        public MemberInfo getInfo()
        {
            MemberInfo mi = new MemberInfo();

            mi.MemberId = Convert.ToInt32(dataGridView1.Rows[dataGridView1.CurrentCellAddress.Y].Cells[0].Value);
            mi.MemberName = dataGridView1.Rows[dataGridView1.CurrentCellAddress.Y].Cells[1].Value.ToString();
            mi.PhoneNum = dataGridView1.Rows[dataGridView1.CurrentCellAddress.Y].Cells[2].Value.ToString();
            mi.Birthdate = (DateTime)dataGridView1.Rows[dataGridView1.CurrentCellAddress.Y].Cells[3].Value;
            mi.address = dataGridView1.Rows[dataGridView1.CurrentCellAddress.Y].Cells[4].Value.ToString();
            mi.Point = Convert.ToInt32(dataGridView1.Rows[dataGridView1.CurrentCellAddress.Y].Cells[5].Value);
            mi.Grade = dataGridView1.Rows[dataGridView1.CurrentCellAddress.Y].Cells[6].Value.ToString();

            return mi;
        }

        private void dataGridView1_RowValidated(object sender, DataGridViewCellEventArgs e)
        {
            DataTable changes = ((DataTable)dataGridView1.DataSource).GetChanges();

            if (changes != null)
            {
                MySqlCommandBuilder mcb = new MySqlCommandBuilder(mySqlDataAdapter);
                mySqlDataAdapter.UpdateCommand = mcb.GetUpdateCommand();
                mySqlDataAdapter.Update(changes);
                ((DataTable)dataGridView1.DataSource).AcceptChanges();
            }
        }
    }
}
