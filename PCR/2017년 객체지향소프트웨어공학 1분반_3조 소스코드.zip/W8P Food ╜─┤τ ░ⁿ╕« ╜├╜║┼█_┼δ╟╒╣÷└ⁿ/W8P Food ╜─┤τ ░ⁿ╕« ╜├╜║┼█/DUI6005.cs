﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using MySql.Data.Common;

namespace W8P_Food_식당_관리_시스템
{
    public partial class DUI6005 : Form
    {
        private MySqlConnection connection;
        private MySqlDataAdapter mySqlDataAdapter;
        W8P_Food_Management_System mainform;
        public DUI6006 dui6006;
        public DUI6005_2 dui6005_2;

        public DUI6005(W8P_Food_Management_System f)
        {
            mainform = f;
            InitializeComponent();
        }

        private void dataGridView1_RowValidated(object sender, DataGridViewCellEventArgs e)
        {
            DataTable changes = ((DataTable)dataGridView1.DataSource).GetChanges();

            if (changes != null)
            {
                MySqlCommandBuilder mcb = new MySqlCommandBuilder(mySqlDataAdapter);
                mySqlDataAdapter.UpdateCommand = mcb.GetUpdateCommand();
                mySqlDataAdapter.Update(changes);
                ((DataTable)dataGridView1.DataSource).AcceptChanges();
            }
        }

        private bool OpenConnection()
        {
            try
            {
                connection.Open();
                return true;
            }
            catch (MySqlException ex)
            {
                switch (ex.Number)
                {
                    case 0:
                        MessageBox.Show("Cannot connect to server. Contact administrator");
                        break;
                    case 1045:
                        MessageBox.Show("Invalid username/password, please try again");
                        break;
                    default:
                        MessageBox.Show(ex.Message);
                        break;
                }
                return false;
            }
        }

        private bool CloseConnection()
        {
            try
            {
                connection.Close();
                return true;
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message);
                return false;
            }
        }

        private void resetDataSheet()
        {
            string strConn = "Server=218.233.209.73;Port=10040;Database=w8p_foodmanagement_system;Uid=root;Pwd=scotish1;pooling = false; convert zero datetime=True";
            connection = new MySqlConnection(strConn);

            if (this.OpenConnection() == true)
            {
                mySqlDataAdapter = new MySqlDataAdapter("select * from orderreturn", connection);
                DataSet DS = new DataSet();
                mySqlDataAdapter.Fill(DS);
                dataGridView1.DataSource = DS.Tables[0];
                this.CloseConnection();
            }
        }

        private void DUI6005_Load(object sender, EventArgs e)
        {
            resetDataSheet();
        }

        // 닫기
        private void btnClose_Click(object sender, EventArgs e)
        {
            mainform.dui6005 = null;
            this.Dispose();
        }

        // 삭제
        private void btn_Click(object sender, EventArgs e)
        {
            string strConn = "Server=218.233.209.73;Port=10040;Database=w8p_foodmanagement_system;Uid=root;Pwd=scotish1;pooling = false; convert zero datetime=True";
            connection = new MySqlConnection(strConn);

            if (this.OpenConnection() == true)
            {
                OrderReturnInfo or = new OrderReturnInfo();
                or = getORInfo();

                // 쿼리문 작성
                string query = "DELETE from orderreturn WHERE id=@id";
                MySqlCommand cmd = new MySqlCommand(query, connection);

                cmd.Parameters.AddWithValue("@id", or.id);
                cmd.ExecuteNonQuery();
                this.CloseConnection();

                resetDataSheet();
            }
        }

        // 수정
        private void button1_Click(object sender, EventArgs e)
        {
            if(dui6006 == null)
            {
                dui6006 = new DUI6006(this);
            }

            dui6006.ShowDialog();
            resetDataSheet();
        }
 
        // 상세 조회
        private void btnDetail_Click(object sender, EventArgs e)
        {
            if (dui6005_2 == null)
            {
                dui6005_2 = new DUI6005_2(this);
            }

            dui6005_2.ShowDialog();
            resetDataSheet();
        }

        public OrderReturnInfo getORInfo()
        {
            OrderReturnInfo or = new OrderReturnInfo();

            or.id = Convert.ToInt32(dataGridView1.Rows[dataGridView1.CurrentCellAddress.Y].Cells[0].Value);
            or.type = dataGridView1.Rows[dataGridView1.CurrentCellAddress.Y].Cells[1].Value.ToString();
            or.provider = dataGridView1.Rows[dataGridView1.CurrentCellAddress.Y].Cells[2].Value.ToString();
            or.date = (DateTime)dataGridView1.Rows[dataGridView1.CurrentCellAddress.Y].Cells[3].Value;
            or.price = Convert.ToInt32(dataGridView1.Rows[dataGridView1.CurrentCellAddress.Y].Cells[4].Value);

            return or;
        }
    }
}
