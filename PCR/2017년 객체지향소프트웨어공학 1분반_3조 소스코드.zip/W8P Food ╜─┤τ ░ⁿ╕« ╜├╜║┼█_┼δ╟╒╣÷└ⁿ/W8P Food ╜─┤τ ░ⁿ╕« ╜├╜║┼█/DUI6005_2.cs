﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using MySql.Data.Common;

namespace W8P_Food_식당_관리_시스템
{
    public partial class DUI6005_2 : Form
    {
        DUI6005 dui6005;
        private MySqlConnection connection;
        private MySqlDataAdapter mySqlDataAdapter;
        W8P_Food_Management_System mainform;
        public DUI6005_2_1 dui6005_2_1;

        public DUI6005_2(DUI6005 f)
        {
            dui6005 = f;
            InitializeComponent();
        }

        private bool OpenConnection()
        {
            try
            {
                connection.Open();
                return true;
            }
            catch (MySqlException ex)
            {
                switch (ex.Number)
                {
                    case 0:
                        MessageBox.Show("Cannot connect to server. Contact administrator");
                        break;
                    case 1045:
                        MessageBox.Show("Invalid username/password, please try again");
                        break;
                    default:
                        MessageBox.Show(ex.Message);
                        break;
                }
                return false;
            }
        }

        private bool CloseConnection()
        {
            try
            {
                connection.Close();
                return true;
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message);
                return false;
            }
        }

        private void DUI6005_2_Load(object sender, EventArgs e)
        {
            resetDataSheet();
        }

        private void resetDataSheet()
        {
            string strConn = "Server=218.233.209.73;Port=10040;Database=w8p_foodmanagement_system;Uid=root;Pwd=scotish1;pooling = false; convert zero datetime=True";
            connection = new MySqlConnection(strConn);

            if (this.OpenConnection() == true)
            {
                OrderReturnInfo or = new OrderReturnInfo();
                or = dui6005.getORInfo();

                string query = "select * from orlist  WHERE ORid=@ORid";
                MySqlCommand cmd = new MySqlCommand(query, connection);

                cmd.Parameters.AddWithValue("@ORid", or.id);
                mySqlDataAdapter = new MySqlDataAdapter();
                mySqlDataAdapter.SelectCommand = cmd;

                DataSet DS = new DataSet();
                mySqlDataAdapter.Fill(DS);
                dataGridView1.DataSource = DS.Tables[0];

                this.CloseConnection();
            }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            if (dui6005_2_1 == null)
            {
                dui6005_2_1 = new DUI6005_2_1(this);
            }

            dui6005_2_1.ShowDialog();
            resetDataSheet();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            string strConn = "Server=218.233.209.73;Port=10040;Database=w8p_foodmanagement_system;Uid=root;Pwd=scotish1;pooling = false; convert zero datetime=True";
            connection = new MySqlConnection(strConn);

            if (this.OpenConnection() == true)
            {
                ORList or = new ORList();
                or = getORLInfo();

                // 쿼리문 작성
                string query = "DELETE from orlist WHERE id=@id";
                MySqlCommand cmd = new MySqlCommand(query, connection);

                cmd.Parameters.AddWithValue("@id", or.id);
                cmd.ExecuteNonQuery();
                this.CloseConnection();

                resetDataSheet();
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            dui6005.dui6005_2 = null;
            this.Dispose();
        }

        public ORList getORLInfo()
        {
            ORList or = new ORList();

            or.id = Convert.ToInt32(dataGridView1.Rows[dataGridView1.CurrentCellAddress.Y].Cells[0].Value);
            or.ORId = Convert.ToInt32(dataGridView1.Rows[dataGridView1.CurrentCellAddress.Y].Cells[1].Value);
            or.ingredientName = dataGridView1.Rows[dataGridView1.CurrentCellAddress.Y].Cells[2].Value.ToString();
            or.amount = Convert.ToInt32(dataGridView1.Rows[dataGridView1.CurrentCellAddress.Y].Cells[3].Value);

            return or;
        }
    }
}
