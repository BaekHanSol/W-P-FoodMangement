﻿namespace W8P_Food_식당_관리_시스템
{
    partial class DUI4001
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.materialTxt = new System.Windows.Forms.TextBox();
            this.식자재명 = new System.Windows.Forms.Label();
            this.amountTxt = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // materialTxt
            // 
            this.materialTxt.Location = new System.Drawing.Point(381, 139);
            this.materialTxt.Name = "materialTxt";
            this.materialTxt.Size = new System.Drawing.Size(100, 21);
            this.materialTxt.TabIndex = 17;
            // 
            // 식자재명
            // 
            this.식자재명.AutoSize = true;
            this.식자재명.Location = new System.Drawing.Point(311, 142);
            this.식자재명.Name = "식자재명";
            this.식자재명.Size = new System.Drawing.Size(53, 12);
            this.식자재명.TabIndex = 16;
            this.식자재명.Text = "식자재명";
            // 
            // amountTxt
            // 
            this.amountTxt.Location = new System.Drawing.Point(381, 181);
            this.amountTxt.Name = "amountTxt";
            this.amountTxt.Size = new System.Drawing.Size(100, 21);
            this.amountTxt.TabIndex = 19;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(311, 184);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(29, 12);
            this.label1.TabIndex = 18;
            this.label1.Text = "수량";
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(418, 249);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(80, 29);
            this.button2.TabIndex = 35;
            this.button2.Text = "취소";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(313, 249);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(84, 29);
            this.button1.TabIndex = 34;
            this.button1.Text = "등록";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // DUI4001
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(827, 466);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.amountTxt);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.materialTxt);
            this.Controls.Add(this.식자재명);
            this.Name = "DUI4001";
            this.Text = "식자재 등록";
            this.Load += new System.EventHandler(this.DUI4001_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox materialTxt;
        private System.Windows.Forms.Label 식자재명;
        private System.Windows.Forms.TextBox amountTxt;
        public System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
    }
}