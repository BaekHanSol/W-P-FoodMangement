﻿namespace W8P_Food_식당_관리_시스템
{
    partial class W8P_Food_Management_System
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.TreeNode treeNode1 = new System.Windows.Forms.TreeNode("예상 판매량 산출");
            System.Windows.Forms.TreeNode treeNode2 = new System.Windows.Forms.TreeNode("식자재 소요량 산출");
            System.Windows.Forms.TreeNode treeNode3 = new System.Windows.Forms.TreeNode("식자재 발주량 결정");
            System.Windows.Forms.TreeNode treeNode4 = new System.Windows.Forms.TreeNode("영업일 등록");
            System.Windows.Forms.TreeNode treeNode5 = new System.Windows.Forms.TreeNode("영업일 조회");
            System.Windows.Forms.TreeNode treeNode6 = new System.Windows.Forms.TreeNode("포인트 적립률 등록");
            System.Windows.Forms.TreeNode treeNode7 = new System.Windows.Forms.TreeNode("포인트 적립률 조회");
            System.Windows.Forms.TreeNode treeNode8 = new System.Windows.Forms.TreeNode("기초자료관리", new System.Windows.Forms.TreeNode[] {
            treeNode4,
            treeNode5,
            treeNode6,
            treeNode7});
            System.Windows.Forms.TreeNode treeNode9 = new System.Windows.Forms.TreeNode("식단 등록");
            System.Windows.Forms.TreeNode treeNode10 = new System.Windows.Forms.TreeNode("식단 조회");
            System.Windows.Forms.TreeNode treeNode11 = new System.Windows.Forms.TreeNode("식단 관리", new System.Windows.Forms.TreeNode[] {
            treeNode9,
            treeNode10});
            System.Windows.Forms.TreeNode treeNode12 = new System.Windows.Forms.TreeNode("식자재 등록");
            System.Windows.Forms.TreeNode treeNode13 = new System.Windows.Forms.TreeNode("식자재 조회");
            System.Windows.Forms.TreeNode treeNode14 = new System.Windows.Forms.TreeNode("식자재 관리", new System.Windows.Forms.TreeNode[] {
            treeNode12,
            treeNode13});
            System.Windows.Forms.TreeNode treeNode15 = new System.Windows.Forms.TreeNode("입출고 등록");
            System.Windows.Forms.TreeNode treeNode16 = new System.Windows.Forms.TreeNode("입출고 조회");
            System.Windows.Forms.TreeNode treeNode17 = new System.Windows.Forms.TreeNode("폐기 등록");
            System.Windows.Forms.TreeNode treeNode18 = new System.Windows.Forms.TreeNode("폐기 조회");
            System.Windows.Forms.TreeNode treeNode19 = new System.Windows.Forms.TreeNode("식자재 입출고 관리", new System.Windows.Forms.TreeNode[] {
            treeNode15,
            treeNode16,
            treeNode17,
            treeNode18});
            System.Windows.Forms.TreeNode treeNode20 = new System.Windows.Forms.TreeNode("발주 반품 정보 등록");
            System.Windows.Forms.TreeNode treeNode21 = new System.Windows.Forms.TreeNode("발주 반품 정보 조회");
            System.Windows.Forms.TreeNode treeNode22 = new System.Windows.Forms.TreeNode("식자재 발주 반품 관리", new System.Windows.Forms.TreeNode[] {
            treeNode20,
            treeNode21});
            System.Windows.Forms.TreeNode treeNode23 = new System.Windows.Forms.TreeNode("발주처 등록");
            System.Windows.Forms.TreeNode treeNode24 = new System.Windows.Forms.TreeNode("발주처 조회");
            System.Windows.Forms.TreeNode treeNode25 = new System.Windows.Forms.TreeNode("발주처 관리", new System.Windows.Forms.TreeNode[] {
            treeNode23,
            treeNode24});
            System.Windows.Forms.TreeNode treeNode26 = new System.Windows.Forms.TreeNode("현재 주문 조회");
            System.Windows.Forms.TreeNode treeNode27 = new System.Windows.Forms.TreeNode("매출 실적 조회");
            System.Windows.Forms.TreeNode treeNode28 = new System.Windows.Forms.TreeNode("주문 관리", new System.Windows.Forms.TreeNode[] {
            treeNode26,
            treeNode27});
            System.Windows.Forms.TreeNode treeNode29 = new System.Windows.Forms.TreeNode("회원 등록");
            System.Windows.Forms.TreeNode treeNode30 = new System.Windows.Forms.TreeNode("회원 조회");
            System.Windows.Forms.TreeNode treeNode31 = new System.Windows.Forms.TreeNode("회원 관리", new System.Windows.Forms.TreeNode[] {
            treeNode29,
            treeNode30});
            System.Windows.Forms.TreeNode treeNode32 = new System.Windows.Forms.TreeNode("예약 등록");
            System.Windows.Forms.TreeNode treeNode33 = new System.Windows.Forms.TreeNode("예약 조회");
            System.Windows.Forms.TreeNode treeNode34 = new System.Windows.Forms.TreeNode("예약 관리", new System.Windows.Forms.TreeNode[] {
            treeNode32,
            treeNode33});
            this.treeView1 = new System.Windows.Forms.TreeView();
            this.panel1 = new System.Windows.Forms.Panel();
            this.SuspendLayout();
            // 
            // treeView1
            // 
            this.treeView1.Location = new System.Drawing.Point(12, 12);
            this.treeView1.Name = "treeView1";
            treeNode1.Name = "uc6001";
            treeNode1.Text = "예상 판매량 산출";
            treeNode2.Name = "uc6002";
            treeNode2.Text = "식자재 소요량 산출";
            treeNode3.Name = "uc6003";
            treeNode3.Text = "식자재 발주량 결정";
            treeNode4.Name = "uc1001";
            treeNode4.Text = "영업일 등록";
            treeNode5.Name = "uc1004";
            treeNode5.Text = "영업일 조회";
            treeNode6.Name = "uc1005";
            treeNode6.Text = "포인트 적립률 등록";
            treeNode7.Name = "uc1008";
            treeNode7.Text = "포인트 적립률 조회";
            treeNode8.Name = "BUC_1";
            treeNode8.Text = "기초자료관리";
            treeNode9.Name = "uc3001";
            treeNode9.Text = "식단 등록";
            treeNode10.Name = "uc3004";
            treeNode10.Text = "식단 조회";
            treeNode11.Name = "BUC_3";
            treeNode11.Text = "식단 관리";
            treeNode12.Name = "uc4001";
            treeNode12.Text = "식자재 등록";
            treeNode13.Name = "uc4004";
            treeNode13.Text = "식자재 조회";
            treeNode14.Name = "BUC_4";
            treeNode14.Text = "식자재 관리";
            treeNode15.Name = "uc5001";
            treeNode15.Text = "입출고 등록";
            treeNode16.Name = "uc5004";
            treeNode16.Text = "입출고 조회";
            treeNode17.Name = "uc5009";
            treeNode17.Text = "폐기 등록";
            treeNode18.Name = "uc5012";
            treeNode18.Text = "폐기 조회";
            treeNode19.Name = "BUC_5";
            treeNode19.Text = "식자재 입출고 관리";
            treeNode20.Name = "uc6004";
            treeNode20.Text = "발주 반품 정보 등록";
            treeNode21.Name = "uc6007";
            treeNode21.Text = "발주 반품 정보 조회";
            treeNode22.Name = "BUC_6_1";
            treeNode22.Text = "식자재 발주 반품 관리";
            treeNode23.Name = "uc6008";
            treeNode23.Text = "발주처 등록";
            treeNode24.Name = "uc6011";
            treeNode24.Text = "발주처 조회";
            treeNode25.Name = "BUC_6_2";
            treeNode25.Text = "발주처 관리";
            treeNode26.Name = "uc7001";
            treeNode26.Text = "현재 주문 조회";
            treeNode27.Name = "uc7004";
            treeNode27.Text = "매출 실적 조회";
            treeNode28.Name = "BUC_7";
            treeNode28.Text = "주문 관리";
            treeNode29.Name = "uc8001";
            treeNode29.Text = "회원 등록";
            treeNode30.Name = "uc8004";
            treeNode30.Text = "회원 조회";
            treeNode31.Name = "BUC_8";
            treeNode31.Text = "회원 관리";
            treeNode32.Name = "uc9001";
            treeNode32.Text = "예약 등록";
            treeNode33.Name = "uc9004";
            treeNode33.Text = "예약 조회";
            treeNode34.Name = "BUC_9";
            treeNode34.Text = "예약 관리";
            this.treeView1.Nodes.AddRange(new System.Windows.Forms.TreeNode[] {
            treeNode1,
            treeNode2,
            treeNode3,
            treeNode8,
            treeNode11,
            treeNode14,
            treeNode19,
            treeNode22,
            treeNode25,
            treeNode28,
            treeNode31,
            treeNode34});
            this.treeView1.Size = new System.Drawing.Size(195, 565);
            this.treeView1.TabIndex = 0;
            this.treeView1.AfterSelect += new System.Windows.Forms.TreeViewEventHandler(this.treeView1_AfterSelect);
            this.treeView1.NodeMouseClick += new System.Windows.Forms.TreeNodeMouseClickEventHandler(this.treeView1_NodeMouseClick);
            // 
            // panel1
            // 
            this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel1.Cursor = System.Windows.Forms.Cursors.Default;
            this.panel1.Location = new System.Drawing.Point(213, 12);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(798, 565);
            this.panel1.TabIndex = 1;
            // 
            // W8P_Food_Management_System
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1023, 589);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.treeView1);
            this.Name = "W8P_Food_Management_System";
            this.Text = "W8P FOOD 식당 관리 시스템";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TreeView treeView1;
        private System.Windows.Forms.Panel panel1;
    }
}

